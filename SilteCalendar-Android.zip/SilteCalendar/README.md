# Silte Calendar 2.0 — native Android (Kotlin + Jetpack Compose)

A full native rewrite of the React/Capacitor **Silte Calendar** (የስልጤ አያም ኢልቅ).

## Open in Android Studio
1. **File ▸ Open…** and pick this folder (the one containing `settings.gradle.kts`).
2. Let Gradle sync (Gradle 8.14.3, AGP 8.11, Kotlin 2.2, compileSdk 36, minSdk 26).
3. Run the `app` configuration on a device or emulator.

## Upgrading the old app
The application ID is still `com.silte.calendar` with `versionCode 2`, so it installs as an
update over the old Capacitor app **if you sign it with the same keystore**.
On first launch, `LegacyImport` reads the old WebView localStorage (`silte_ev`, `silte_col`,
language, theme, toggles…) and imports everything once — users keep their events.

## Features
- **Three calendars** — Silte, Ethiopian or Gregorian as the main grid, with the other two shown in each cell
  (ported 1:1 from the original formulas; verified against the original JavaScript over 65,000 days).
- **Swipeable month view** with a "today" card, month/year picker, Silte New Year banner and ቃቅሜ leap badge.
- **Events** — time or all-day, reminders, repeat daily/weekly/every Silte month/every Silte year, colors,
  search, filters, swipe-to-delete with undo, sharing.
- **Holidays** — Ethiopian public holidays, Silte Freedom Day and Silte New Year, Orthodox fasts and moveable feasts
  (Fasika computed yearly), Islamic holidays via the Umm al-Qura calendar.
- **Notifications** — exact event reminders with snooze, silent morning summary (all three dates + holidays),
  rescheduled after reboot/time-zone change.
- **Widgets** (Jetpack Glance) — Today, Month and Agenda, themed with the app's colors, refreshed at midnight.
- **Converter** between all three calendars, with weekday and "days from today".
- **Personalization** — light/dark/system, primary & weekend colors (presets or custom), Material You,
  Ge'ez numerals, English/አማርኛ (also in Android's per-app language settings).
- **Data** — JSON backup/restore (compatible with old backups), month JSON export, `.ics` export for Google/Outlook.
- App shortcuts (long-press icon), splash screen, edge-to-edge, predictive back, themed icon.

## Structure
```
core/      calendar engine, names, Ge'ez numerals, holidays, recurrence   (pure Kotlin, unit-tested)
data/      Room events, DataStore settings, backup/export, legacy import
notify/    notification channels, AlarmManager scheduling, receivers
widget/    Glance widgets
ui/        Compose screens: month, events, holidays, convert, editor, settings, onboarding
```

## Tests
`./gradlew test` runs `CalendarsTest` (known dates, 200-year round trip, leap years, Ge'ez numerals, Easter).

## Build the APK on GitHub (no Android Studio needed)
Push this project to a GitHub repository. The workflow in `.github/workflows/build-apk.yml`
runs automatically (or start it from **Actions ▸ Build APK ▸ Run workflow**). When it finishes,
download **SilteCalendar-debug-apk** from the run's *Artifacts* section.

The debug APK is for testing. For the Play Store, build a signed release with your original keystore:
**Build ▸ Generate Signed App Bundle / APK** in Android Studio.
