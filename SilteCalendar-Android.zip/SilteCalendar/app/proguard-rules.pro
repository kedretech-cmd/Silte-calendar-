# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.silte.calendar.**$$serializer { *; }
-keepclassmembers class com.silte.calendar.** { *** Companion; }
-keepclasseswithmembers class com.silte.calendar.** { kotlinx.serialization.KSerializer serializer(...); }
