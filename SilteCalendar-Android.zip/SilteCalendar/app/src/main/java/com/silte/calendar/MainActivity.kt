package com.silte.calendar

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.activity.compose.setContent
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.data.LegacyImport
import com.silte.calendar.ui.LaunchRequest
import com.silte.calendar.ui.MainViewModel
import com.silte.calendar.ui.SilteCalendarApp
import com.silte.calendar.ui.theme.SilteTheme
import com.silte.calendar.ui.theme.isDark
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: MainViewModel by viewModels { MainViewModel.factory(container) }
    private var launchRequest by mutableStateOf<LaunchRequest?>(null)
    private var jumpRequest by mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        // Keep the splash until settings are loaded and the one-time import from the old app is done.
        splash.setKeepOnScreenCondition { vm.settings.value?.legacyImported != true }

        lifecycleScope.launch {
            runCatching { LegacyImport.runOnce(this@MainActivity, container.settings, container.events) }
            if (container.settings.current().legacyImported.not()) {
                container.settings.update { it.copy(legacyImported = true) }
            }
        }

        if (savedInstanceState == null) launchRequest = parse(intent)

        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val s = settings ?: return@setContent
            val dark = isDark(s)
            LaunchedEffect(dark) {
                // Status/navigation bar icons follow the app theme, not just the system theme.
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                )
            }
            SilteTheme(s) {
                SilteCalendarApp(
                    vm = vm,
                    settings = s,
                    launchRequest = launchRequest,
                    onLaunchHandled = { launchRequest = null },
                    jumpRequest = jumpRequest,
                    onJump = { jumpRequest = it },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        launchRequest = parse(intent)
    }

    private fun parse(intent: Intent?): LaunchRequest? {
        intent ?: return null
        return when (intent.action) {
            ACTION_NEW_EVENT -> LaunchRequest.NewEvent(intent.getLongExtra(EXTRA_EPOCH_DAY, todayEpochDay()))
            ACTION_CONVERT -> LaunchRequest.Convert
            ACTION_EVENTS -> LaunchRequest.Events
            else -> if (intent.hasExtra(EXTRA_EPOCH_DAY)) LaunchRequest.OpenDay(intent.getLongExtra(EXTRA_EPOCH_DAY, todayEpochDay())) else null
        }
    }

    companion object {
        const val EXTRA_EPOCH_DAY = "epoch_day"
        const val ACTION_NEW_EVENT = "com.silte.calendar.action.NEW_EVENT"
        const val ACTION_CONVERT = "com.silte.calendar.action.CONVERT"
        const val ACTION_EVENTS = "com.silte.calendar.action.EVENTS"
    }
}
