package com.silte.calendar

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.silte.calendar.core.HolidayProvider
import com.silte.calendar.core.IcuHijri
import com.silte.calendar.data.AppDatabase
import com.silte.calendar.data.EventRepository
import com.silte.calendar.data.SettingsRepository
import com.silte.calendar.notify.Notifications
import com.silte.calendar.notify.ReminderScheduler
import com.silte.calendar.widget.WidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch

/** Manual dependency injection: one instance of each service for the whole app. */
class AppContainer(private val context: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "silte_calendar.db").build()

    val settings = SettingsRepository(context)
    val holidays = HolidayProvider(IcuHijri)
    val scheduler = ReminderScheduler(context)
    val events: EventRepository = EventRepository(db.events()) { syncAll() }

    /** Re-schedules every alarm and redraws widgets. Called after any data or settings change. */
    suspend fun syncAll() {
        scheduler.rescheduleAll(events.all(), settings.current())
        WidgetUpdater.updateAll(context)
    }
}

class SilteApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifications.createChannels(this)
        container.scope.launch {
            container.syncAll()
            // Settings such as colors, primary calendar or digest time affect alarms and widgets.
            container.settings.settings.drop(1).collect { container.syncAll() }
        }
    }
}

val Context.container: AppContainer get() = (applicationContext as SilteApp).container
