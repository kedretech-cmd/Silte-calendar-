package com.silte.calendar.core

import java.time.LocalDate

/** A plain year-month-day triple in some [CalendarSystem]. */
data class Ymd(val year: Int, val month: Int, val day: Int) : Comparable<Ymd> {
    override fun compareTo(other: Ymd): Int =
        compareValuesBy(this, other, Ymd::year, Ymd::month, Ymd::day)

    /** Storage key used by the original app: "1448-5-20". */
    val key: String get() = "$year-$month-$day"

    companion object {
        fun parseKey(key: String): Ymd? {
            val parts = key.split("-").mapNotNull { it.trim().toIntOrNull() }
            return if (parts.size == 3) Ymd(parts[0], parts[1], parts[2]) else null
        }
    }
}

/**
 * The three calendars the app can show as its main grid.
 *
 * All conversions go through the *epoch day* (days since 1970-01-01), which equals
 * the Julian Day Number minus [JDN_UNIX_EPOCH]. The Silte and Ethiopian formulas are
 * ported 1:1 from the original React app so stored dates stay compatible.
 */
enum class CalendarSystem {
    SILTE, ETHIOPIAN, GREGORIAN;

    fun toEpochDay(year: Int, month: Int, day: Int): Long = when (this) {
        SILTE -> Ethiopic.toJdn(year, month, day, SILTE_EPOCH) - JDN_UNIX_EPOCH
        ETHIOPIAN -> Ethiopic.toJdn(year, month, day, ETHIOPIAN_EPOCH) - JDN_UNIX_EPOCH
        GREGORIAN -> LocalDate.of(year, month, day).toEpochDay()
    }

    fun toEpochDay(ymd: Ymd): Long = toEpochDay(ymd.year, ymd.month, ymd.day)

    fun fromEpochDay(epochDay: Long): Ymd = when (this) {
        SILTE -> Ethiopic.fromJdn(epochDay + JDN_UNIX_EPOCH, SILTE_EPOCH)
        ETHIOPIAN -> Ethiopic.fromJdn(epochDay + JDN_UNIX_EPOCH, ETHIOPIAN_EPOCH)
        GREGORIAN -> LocalDate.ofEpochDay(epochDay).let { Ymd(it.year, it.monthValue, it.dayOfMonth) }
    }

    fun monthsInYear(): Int = if (this == GREGORIAN) 12 else 13

    fun isLeapYear(year: Int): Boolean = when (this) {
        GREGORIAN -> java.time.Year.isLeap(year.toLong())
        else -> Math.floorMod(year + 1, 4) == 0
    }

    fun daysInMonth(year: Int, month: Int): Int = when (this) {
        GREGORIAN -> java.time.YearMonth.of(year, month).lengthOfMonth()
        else -> if (month == 13) (if (isLeapYear(year)) 6 else 5) else 30
    }

    fun isValid(year: Int, month: Int, day: Int): Boolean =
        year > 0 && month in 1..monthsInYear() && day in 1..daysInMonth(year, month)

    fun today(): Ymd = fromEpochDay(LocalDate.now().toEpochDay())

    companion object {
        const val JDN_UNIX_EPOCH = 2_440_588L
        const val SILTE_EPOCH = 1_932_337L
        const val ETHIOPIAN_EPOCH = 1_723_855L

        fun fromKey(key: String?): CalendarSystem =
            when (key) {
                "ethio", "ETHIOPIAN" -> ETHIOPIAN
                "greg", "GREGORIAN" -> GREGORIAN
                else -> SILTE
            }
    }
}

/** Shared arithmetic for the 13-month calendars (Silte and Ethiopian differ only by epoch). */
private object Ethiopic {
    fun toJdn(year: Int, month: Int, day: Int, epoch: Long): Long =
        365L * year + Math.floorDiv(year, 4) + 30L * (month - 1) + day + epoch

    fun fromJdn(jdn: Long, epoch: Long): Ymd {
        var year = Math.floorDiv(4L * (jdn - epoch), 1461L).toInt()
        while (toJdn(year + 1, 1, 1, epoch) <= jdn) year++
        while (toJdn(year, 1, 1, epoch) > jdn) year--
        val dayOfYear = (jdn - toJdn(year, 1, 1, epoch)).toInt() // 0-based
        val month = minOf(13, dayOfYear / 30 + 1)
        val day = dayOfYear - 30 * (month - 1) + 1
        return Ymd(year, month, day)
    }
}

/** 0 = Sunday … 6 = Saturday, matching the original app's `(JDN + 1) % 7`. */
fun weekdayOf(epochDay: Long): Int = Math.floorMod(epochDay + CalendarSystem.JDN_UNIX_EPOCH + 1, 7L).toInt()

fun todayEpochDay(): Long = LocalDate.now().toEpochDay()

/** A month in some calendar, used for paging. */
data class CalMonth(val system: CalendarSystem, val year: Int, val month: Int) {
    val index: Int get() = year * system.monthsInYear() + (month - 1)
    val length: Int get() = system.daysInMonth(year, month)
    val firstEpochDay: Long get() = system.toEpochDay(year, month, 1)
    val lastEpochDay: Long get() = firstEpochDay + length - 1

    fun plus(months: Int): CalMonth = fromIndex(system, index + months)

    companion object {
        fun fromIndex(system: CalendarSystem, index: Int): CalMonth {
            val n = system.monthsInYear()
            return CalMonth(system, Math.floorDiv(index, n), Math.floorMod(index, n) + 1)
        }

        fun containing(system: CalendarSystem, epochDay: Long): CalMonth =
            system.fromEpochDay(epochDay).let { CalMonth(system, it.year, it.month) }
    }
}

/** One cell of the month grid. */
data class DayCell(
    val epochDay: Long,
    val primary: Ymd,
    val inMonth: Boolean,
    val weekday: Int,
)

object MonthGrid {
    /**
     * Sunday-first grid like the original app: leading days from the previous month,
     * the month itself, and trailing days to complete the final week.
     */
    fun build(month: CalMonth): List<DayCell> {
        val first = month.firstEpochDay
        val leading = weekdayOf(first)
        val total = leading + month.length
        val cells = if (total % 7 == 0) total else total + (7 - total % 7)
        return List(cells) { i ->
            val epoch = first - leading + i
            DayCell(
                epochDay = epoch,
                primary = month.system.fromEpochDay(epoch),
                inMonth = i >= leading && i < leading + month.length,
                weekday = i % 7,
            )
        }
    }
}
