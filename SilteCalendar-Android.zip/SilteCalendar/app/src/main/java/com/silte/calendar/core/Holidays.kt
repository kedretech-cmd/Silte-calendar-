package com.silte.calendar.core

import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap

enum class HolidayType { PUBLIC, ORTHODOX, MUSLIM }

data class Holiday(
    val nameEn: String,
    val nameAm: String,
    val type: HolidayType,
    val epochDay: Long,
    /** Public holidays are days off in Ethiopia. */
    val dayOff: Boolean = type == HolidayType.PUBLIC,
    /** Islamic dates depend on moon sighting and can shift by a day. */
    val approximate: Boolean = false,
) {
    fun name(amharic: Boolean) = if (amharic) nameAm else nameEn
}

data class HolidayFilter(val public: Boolean = true, val orthodox: Boolean = true, val muslim: Boolean = true) {
    fun accepts(h: Holiday) = when (h.type) {
        HolidayType.PUBLIC -> public
        HolidayType.ORTHODOX -> orthodox
        HolidayType.MUSLIM -> muslim
    }
}

/** Converts a Hijri date to an epoch day. Implemented with ICU on Android ([IcuHijri]). */
fun interface HijriConverter {
    fun toEpochDay(year: Int, month: Int, day: Int): Long
}

/**
 * Holidays observed in Ethiopia and by the Silte community.
 *
 * Improvements over the original app, which used fixed dates:
 *  - Fasika and Siklet move every year; they are computed with the Orthodox Easter algorithm.
 *  - Eid al-Fitr, Arafa and Mawlid follow the Hijri calendar instead of fixed Gregorian dates.
 */
class HolidayProvider(private val hijri: HijriConverter) {

    private val cache = ConcurrentHashMap<Int, List<Holiday>>()

    /** All holidays in the Gregorian year, cached. */
    fun forGregorianYear(year: Int): List<Holiday> = cache.getOrPut(year) { compute(year) }

    fun inRange(fromEpoch: Long, toEpoch: Long, filter: HolidayFilter): Map<Long, List<Holiday>> {
        val y1 = LocalDate.ofEpochDay(fromEpoch).year
        val y2 = LocalDate.ofEpochDay(toEpoch).year
        return (y1..y2).asSequence()
            .flatMap { forGregorianYear(it).asSequence() }
            .filter { it.epochDay in fromEpoch..toEpoch && filter.accepts(it) }
            .groupBy { it.epochDay }
    }

    fun on(epochDay: Long, filter: HolidayFilter): List<Holiday> =
        forGregorianYear(LocalDate.ofEpochDay(epochDay).year).filter { it.epochDay == epochDay && filter.accepts(it) }

    private fun compute(year: Int): List<Holiday> {
        val start = LocalDate.of(year, 1, 1).toEpochDay()
        val end = LocalDate.of(year, 12, 31).toEpochDay()
        val out = mutableListOf<Holiday>()
        fun add(en: String, am: String, type: HolidayType, epoch: Long, approx: Boolean = false, dayOff: Boolean? = null) {
            if (epoch in start..end) {
                out += Holiday(en, am, type, epoch, dayOff ?: (type == HolidayType.PUBLIC), approx)
            }
        }

        val eth = CalendarSystem.ETHIOPIAN
        val silte = CalendarSystem.SILTE
        // A Gregorian year overlaps two Ethiopian years and two Silte years.
        for (ey in (year - 8)..(year - 7)) {
            fun e(m: Int, d: Int) = eth.toEpochDay(ey, m, d)
            add("Ethiopian New Year (Enkutatash)", "እንቁጣጣሽ / የዘመን መለወጫ", HolidayType.PUBLIC, e(1, 1))
            add("Finding of the True Cross (Meskel)", "የመስቀል በዓል", HolidayType.PUBLIC, e(1, 17))
            add("Genna (Ethiopian Christmas)", "የገና በዓል (የልደት ቀን)", HolidayType.PUBLIC, e(4, 29))
            add("Timkat (Ethiopian Epiphany)", "የጥምቀት በዓል", HolidayType.PUBLIC, e(5, 11))
            add("Victory of Adwa", "የአድዋ ድል መታሰቢያ", HolidayType.PUBLIC, e(6, 23))
            add("Silte People's Freedom Day", "መጋቢት 23 የስልጤ ህዝብ ነፃነት ቀን", HolidayType.PUBLIC, e(7, 23))
            add("Patriots' Day", "የአርበኞች ቀን", HolidayType.PUBLIC, e(8, 27))
            add("Downfall of the Derg", "ደርግ የወደቀበት ቀን", HolidayType.PUBLIC, e(9, 20))
            add("Start of Filseta fast", "ጾመ ፍልሰታ መግቢያ", HolidayType.ORTHODOX, e(12, 1))
            add("Filseta (Assumption of Mary)", "ፍልሰታ ለማርያም", HolidayType.ORTHODOX, e(12, 16))
        }
        for (sy in silte.fromEpochDay(start).year..silte.fromEpochDay(end).year) {
            add("Silte New Year", "የስልጤ ዘመን መለወጫ", HolidayType.PUBLIC, silte.toEpochDay(sy, 1, 1), dayOff = false)
        }

        add("International Labour Day", "ዓለም አቀፍ የሠራተኞች ቀን", HolidayType.PUBLIC, LocalDate.of(year, 5, 1).toEpochDay())

        // Moveable Orthodox feasts, all relative to Fasika.
        val easter = orthodoxEaster(year).toEpochDay()
        add("Good Friday (Siklet)", "ስቅለት", HolidayType.PUBLIC, easter - 2)
        add("Fasika (Ethiopian Easter)", "ፋሲካ (የትንሣኤ በዓል)", HolidayType.PUBLIC, easter)
        add("Fast of Nineveh", "ጾመ ነነዌ", HolidayType.ORTHODOX, easter - 69)
        add("Start of Abiy Tsom (Lent)", "ዐቢይ ጾም (ሁዳዴ) መግቢያ", HolidayType.ORTHODOX, easter - 55)
        add("Debre Zeit", "ደብረ ዘይት", HolidayType.ORTHODOX, easter - 28)
        add("Hosanna (Palm Sunday)", "ሆሳዕና", HolidayType.ORTHODOX, easter - 7)
        add("Start of Apostles' Fast", "ጾመ ሐዋርያት መግቢያ", HolidayType.ORTHODOX, easter + 50)

        // Islamic holidays: a Gregorian year spans two Hijri years.
        val hijriYear = estimateHijriYear(year)
        for (hy in hijriYear..hijriYear + 2) {
            fun h(m: Int, d: Int) = runCatching { hijri.toEpochDay(hy, m, d) }.getOrDefault(Long.MIN_VALUE)
            add("Eid al-Fitr", "ዒድ አል-ፊጥር (የረመዳን በዓል)", HolidayType.PUBLIC, h(10, 1), approx = true)
            add("Eid al-Adha (Arafa)", "ዒድ አል-አድሐ (አረፋ በዓል)", HolidayType.PUBLIC, h(12, 10), approx = true)
            add("Mawlid (Prophet's Birthday)", "መውሊድ", HolidayType.PUBLIC, h(3, 12), approx = true)
            add("Islamic New Year", "የሂጅራ አዲስ ዓመት", HolidayType.MUSLIM, h(1, 1), approx = true)
            add("Ashura", "አሹራ", HolidayType.MUSLIM, h(1, 10), approx = true)
            add("Isra and Mi'raj", "ኢስራእ እና ሚዕራጅ", HolidayType.MUSLIM, h(7, 27), approx = true)
            add("Start of Ramadan", "የረመዳን ጾም መግቢያ", HolidayType.MUSLIM, h(9, 1), approx = true)
            add("Laylat al-Qadr", "ለይለተል ቀድር", HolidayType.MUSLIM, h(9, 27), approx = true)
        }

        return out.sortedBy { it.epochDay }
    }

    /** Hijri year that begins in (or just before) the given Gregorian year. */
    private fun estimateHijriYear(gregorianYear: Int): Int =
        ((gregorianYear - 622) * 33.0 / 32.0).toInt() - 1

    companion object {
        /** Orthodox Easter as a Gregorian date (Meeus' Julian algorithm + 13 days, valid 1900–2099). */
        fun orthodoxEaster(year: Int): LocalDate {
            val a = year % 4
            val b = year % 7
            val c = year % 19
            val d = (19 * c + 15) % 30
            val e = (2 * a + 4 * b - d + 34) % 7
            val month = (d + e + 114) / 31
            val day = (d + e + 114) % 31 + 1
            return LocalDate.of(year, month, day).plusDays(13)
        }
    }
}
