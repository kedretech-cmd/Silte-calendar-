package com.silte.calendar.core

import android.icu.util.Calendar
import android.icu.util.IslamicCalendar
import android.icu.util.TimeZone
import java.time.Instant
import java.time.ZoneOffset

/** Umm al-Qura Hijri conversion using the ICU calendar built into Android (API 24+). */
object IcuHijri : HijriConverter {
    override fun toEpochDay(year: Int, month: Int, day: Int): Long {
        val cal = IslamicCalendar(TimeZone.GMT_ZONE)
        cal.calculationType = IslamicCalendar.CalculationType.ISLAMIC_UMALQURA
        cal.clear()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, day)
        cal.set(Calendar.HOUR_OF_DAY, 12)
        return Instant.ofEpochMilli(cal.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
    }
}
