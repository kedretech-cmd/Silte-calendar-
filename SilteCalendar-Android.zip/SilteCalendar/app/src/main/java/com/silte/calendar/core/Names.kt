package com.silte.calendar.core

import java.time.format.TextStyle
import java.util.Locale

object Names {
    val silteMonths = listOf(
        "መሰሮ", "ጢቂምት", "ሂዳር", "መሼ", "ኢንቶጎት", "መንገስ", "ወቶ",
        "ማዜ", "አስሬ", "ሰኜ", "አምሌ", "ናሴ", "ቃቅሜ",
    )
    val ethiopianMonths = listOf(
        "መስከረም", "ጥቅምት", "ህዳር", "ታሕሣሥ", "ጥር", "የካቲት", "መጋቢት",
        "ሚያዚያ", "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ", "ጳጉሜ",
    )

    /** Silte weekday names, index 0 = Sunday. */
    val silteWeekdays = listOf("ግድር", "ኡጠት", "መገር", "አርጴ", "ከምስ", "ጂማት", "አንሰ")
    val silteWeekdaysShort = listOf("ግ", "ኡ", "መ", "አ", "ከ", "ጂ", "አን")

    fun gregorianMonth(month: Int, short: Boolean = false, locale: Locale = Locale.getDefault()): String =
        java.time.Month.of(month).getDisplayName(if (short) TextStyle.SHORT else TextStyle.FULL, locale)

    fun gregorianWeekdayShort(index: Int, locale: Locale = Locale.getDefault()): String =
        java.time.DayOfWeek.of(if (index == 0) 7 else index).getDisplayName(TextStyle.NARROW, locale)

    fun gregorianWeekday(index: Int, locale: Locale = Locale.getDefault()): String =
        java.time.DayOfWeek.of(if (index == 0) 7 else index).getDisplayName(TextStyle.FULL, locale)

    fun monthName(system: CalendarSystem, month: Int, short: Boolean = false): String = when (system) {
        CalendarSystem.SILTE -> silteMonths[month - 1]
        CalendarSystem.ETHIOPIAN -> ethiopianMonths[month - 1]
        CalendarSystem.GREGORIAN -> gregorianMonth(month, short)
    }

    fun weekdayHeaders(system: CalendarSystem): List<String> =
        if (system == CalendarSystem.GREGORIAN) List(7) { gregorianWeekdayShort(it) } else silteWeekdaysShort
}

/** Ge'ez (Ethiopic) numerals, e.g. 1448 → ፲፬፻፵፰. */
object Geez {
    private const val ONES = "፩፪፫፬፭፮፯፰፱"
    private const val TENS = "፲፳፴፵፶፷፸፹፺"

    fun format(number: Int): String {
        if (number <= 0) return number.toString()
        val groups = mutableListOf<Int>()
        var n = number
        while (n > 0) {
            groups += n % 100
            n /= 100
        }
        val sb = StringBuilder()
        for (i in groups.indices.reversed()) {
            val g = groups[i]
            val omitOne = g == 1 && i > 0 && !(i == groups.lastIndex && i % 2 == 0)
            if (g != 0 && !omitOne) sb.append(twoDigits(g))
            if (i > 0 && (g != 0 || i % 2 == 0)) sb.append(if (i % 2 == 1) '፻' else '፼')
        }
        return sb.toString()
    }

    private fun twoDigits(n: Int) = buildString {
        if (n / 10 > 0) append(TENS[n / 10 - 1])
        if (n % 10 > 0) append(ONES[n % 10 - 1])
    }
}

/** Consistent date strings for screens, widgets and notifications. */
object Fmt {
    fun num(n: Int, geez: Boolean) = if (geez) Geez.format(n) else n.toString()

    /** "ኢንቶጎት 20፣ 1448" — month-first, as in the original app. */
    fun date(system: CalendarSystem, ymd: Ymd, geez: Boolean = false): String = when (system) {
        CalendarSystem.SILTE -> "${Names.silteMonths[ymd.month - 1]} ${num(ymd.day, geez)}፣ ${num(ymd.year, geez)}"
        CalendarSystem.ETHIOPIAN -> "${Names.ethiopianMonths[ymd.month - 1]} ${num(ymd.day, geez)}፣ ${num(ymd.year, geez)} ዓ.ም"
        CalendarSystem.GREGORIAN -> "${ymd.day} ${Names.gregorianMonth(ymd.month)} ${ymd.year}"
    }

    fun date(system: CalendarSystem, epochDay: Long, geez: Boolean = false): String =
        date(system, system.fromEpochDay(epochDay), geez)

    fun monthTitle(month: CalMonth, geez: Boolean = false): String = when (month.system) {
        CalendarSystem.SILTE -> "${Names.silteMonths[month.month - 1]} ${num(month.year, geez)}"
        CalendarSystem.ETHIOPIAN -> "${Names.ethiopianMonths[month.month - 1]} ${num(month.year, geez)} ዓ.ም"
        CalendarSystem.GREGORIAN -> "${Names.gregorianMonth(month.month)} ${month.year}"
    }

    /** Span of another calendar covered by [month], e.g. "Oct – Nov 2026" or "ጥቅምት – ህዳር 2019 ዓ.ም". */
    fun span(month: CalMonth, other: CalendarSystem): String {
        val a = other.fromEpochDay(month.firstEpochDay)
        val b = other.fromEpochDay(month.lastEpochDay)
        val short = other == CalendarSystem.GREGORIAN
        val ma = Names.monthName(other, a.month, short)
        val mb = Names.monthName(other, b.month, short)
        val suffix = if (other == CalendarSystem.ETHIOPIAN) " ዓ.ም" else ""
        return when {
            a.year != b.year -> "$ma ${a.year}$suffix – $mb ${b.year}$suffix"
            a.month == b.month -> "$ma ${a.year}$suffix"
            else -> "$ma – $mb ${b.year}$suffix"
        }
    }

    fun time(hour: Int, minute: Int, is24h: Boolean): String =
        if (is24h) "%02d:%02d".format(hour, minute)
        else "%d:%02d %s".format(if (hour % 12 == 0) 12 else hour % 12, minute, if (hour < 12) "AM" else "PM")
}
