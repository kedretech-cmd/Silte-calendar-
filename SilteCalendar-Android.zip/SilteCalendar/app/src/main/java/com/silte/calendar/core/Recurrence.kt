package com.silte.calendar.core

/** How an event repeats. Monthly and yearly repetition follow the Silte calendar. */
enum class Recurrence {
    NONE, DAILY, WEEKLY, MONTHLY, YEARLY;

    /** Whether an event starting on [startEpoch] occurs on [epochDay]. */
    fun occursOn(startEpoch: Long, epochDay: Long): Boolean {
        val diff = epochDay - startEpoch
        if (diff < 0) return false
        return when (this) {
            NONE -> diff == 0L
            DAILY -> true
            WEEKLY -> diff % 7 == 0L
            MONTHLY -> silteOf(epochDay).day == silteOf(startEpoch).day
            YEARLY -> silteOf(epochDay).let { d -> val s = silteOf(startEpoch); d.month == s.month && d.day == s.day }
        }
    }

    /** First occurrence on or after [fromEpoch], searching one full 4-year cycle. */
    fun nextOccurrence(startEpoch: Long, fromEpoch: Long): Long? {
        if (fromEpoch <= startEpoch) return startEpoch
        if (this == NONE) return null
        var e = fromEpoch
        val limit = fromEpoch + 1461 + 31
        while (e <= limit) {
            if (occursOn(startEpoch, e)) return e
            e++
        }
        return null
    }

    companion object {
        fun from(name: String?): Recurrence = entries.firstOrNull { it.name == name } ?: NONE
        private fun silteOf(epochDay: Long) = CalendarSystem.SILTE.fromEpochDay(epochDay)
    }
}
