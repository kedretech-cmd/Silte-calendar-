package com.silte.calendar.data

import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Names
import com.silte.calendar.core.Recurrence
import com.silte.calendar.core.Ymd
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/** Event JSON shape shared with the original app's backups (extra fields are optional). */
@Serializable
data class BackupEvent(
    val id: String? = null,
    val title: String,
    val description: String? = "",
    val dateKey: String,
    val isAllDay: Boolean? = true,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,
    val recurrence: String? = null,
    val remindBefore: Int? = null,
    val color: Int? = null,
)

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class BackupFile(
    @EncodeDefault val app: String = "silte-calendar",
    @EncodeDefault val version: Int = 2,
    @EncodeDefault val notes: JsonElement = JsonObject(emptyMap()),
    val events: List<BackupEvent>,
)

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class MonthExport(
    val month: Int,
    val year: Int,
    val monthName: String,
    val isLeapYear: Boolean,
    val pagumeDays: Int,
    @EncodeDefault val notes: JsonElement = JsonObject(emptyMap()),
    val events: List<BackupEvent>,
)

@OptIn(ExperimentalSerializationApi::class)
object Backup {
    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
        prettyPrint = true
        explicitNulls = false
    }

    fun toBackup(e: EventEntity) = BackupEvent(
        id = e.id, title = e.title, description = e.description, dateKey = e.dateKey,
        isAllDay = e.isAllDay, reminderHour = e.reminderHour, reminderMinute = e.reminderMinute,
        recurrence = e.recurrence, remindBefore = e.remindBefore, color = e.color,
    )

    fun fromBackup(b: BackupEvent): EventEntity? {
        val ymd = Ymd.parseKey(b.dateKey) ?: return null
        if (!CalendarSystem.SILTE.isValid(ymd.year, ymd.month, ymd.day) || b.title.isBlank()) return null
        val epoch = CalendarSystem.SILTE.toEpochDay(ymd)
        return EventEntity(
            id = b.id?.takeIf { it.isNotBlank() } ?: java.util.UUID.randomUUID().toString(),
            title = b.title.trim(),
            description = b.description.orEmpty(),
            dateKey = ymd.key,
            epochDay = epoch,
            isAllDay = b.isAllDay ?: true,
            reminderHour = b.reminderHour,
            reminderMinute = b.reminderMinute,
            recurrence = Recurrence.from(b.recurrence).name,
            remindBefore = b.remindBefore ?: 0,
            color = b.color,
        )
    }

    fun encode(events: List<EventEntity>): String =
        json.encodeToString(BackupFile.serializer(), BackupFile(events = events.map(::toBackup)))

    /** Parses a backup from this app or the original one (`{"notes":{},"events":[...]}`). */
    fun decode(text: String): List<EventEntity> =
        json.decodeFromString(BackupFile.serializer(), text).events.mapNotNull(::fromBackup)

    /** Same JSON layout as the original app's "Export Calendar" screen. */
    fun exportMonth(month: CalMonth, events: List<EventEntity>): String {
        val silte = CalendarSystem.SILTE
        val inMonth = events.filter { silte.fromEpochDay(it.epochDay).let { d -> d.year == month.year && d.month == month.month } }
        val export = MonthExport(
            month = month.month, year = month.year, monthName = Names.silteMonths[month.month - 1],
            isLeapYear = silte.isLeapYear(month.year), pagumeDays = silte.daysInMonth(month.year, 13),
            events = inMonth.map(::toBackup),
        )
        return json.encodeToString(MonthExport.serializer(), export)
    }

    /**
     * iCalendar (.ics) export, importable into Google Calendar, Outlook, etc.
     * Silte-monthly/yearly repeats have no RRULE equivalent, so they are expanded for [expandYears].
     */
    fun toIcs(events: List<EventEntity>, expandYears: Int = 5): String {
        val sb = StringBuilder()
        fun line(s: String) = sb.append(fold(s)).append("\r\n")
        val stamp = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"))
        val dateFmt = DateTimeFormatter.BASIC_ISO_DATE

        line("BEGIN:VCALENDAR")
        line("VERSION:2.0")
        line("PRODID:-//Silte Calendar//EN")
        line("CALSCALE:GREGORIAN")
        line("X-WR-CALNAME:Silte Calendar")

        for (e in events) {
            val repeat = e.repeat
            val starts: List<Long> = when (repeat) {
                Recurrence.MONTHLY, Recurrence.YEARLY -> {
                    val end = e.epochDay + 365L * expandYears
                    EventRepository.occurrences(listOf(e), e.epochDay, end).keys.sorted()
                }
                else -> listOf(e.epochDay)
            }
            starts.forEachIndexed { i, day ->
                val date = LocalDate.ofEpochDay(day)
                line("BEGIN:VEVENT")
                line("UID:${e.id}-$i@silte.calendar")
                line("DTSTAMP:$stamp")
                if (e.isAllDay || e.reminderHour == null) {
                    line("DTSTART;VALUE=DATE:${date.format(dateFmt)}")
                    line("DTEND;VALUE=DATE:${date.plusDays(1).format(dateFmt)}")
                } else {
                    val t = "%02d%02d00".format(e.reminderHour, e.reminderMinute ?: 0)
                    line("DTSTART:${date.format(dateFmt)}T$t")
                }
                when (repeat) {
                    Recurrence.DAILY -> line("RRULE:FREQ=DAILY")
                    Recurrence.WEEKLY -> line("RRULE:FREQ=WEEKLY")
                    else -> Unit
                }
                line("SUMMARY:${escape(e.title)}")
                val silteDate = "Silte: " + com.silte.calendar.core.Fmt.date(CalendarSystem.SILTE, day)
                line("DESCRIPTION:${escape(listOf(e.description, silteDate).filter { it.isNotBlank() }.joinToString("\n"))}")
                if (e.remindBefore >= 0) {
                    line("BEGIN:VALARM")
                    line("ACTION:DISPLAY")
                    line("DESCRIPTION:${escape(e.title)}")
                    line("TRIGGER:-PT${e.remindBefore}M")
                    line("END:VALARM")
                }
                line("END:VEVENT")
            }
        }
        line("END:VCALENDAR")
        return sb.toString()
    }

    private fun escape(s: String) =
        s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

    /** RFC 5545 line folding at 75 octets. */
    private fun fold(s: String): String {
        val bytes = s.toByteArray(Charsets.UTF_8)
        if (bytes.size <= 75) return s
        val out = StringBuilder()
        var count = 0
        for (ch in s) {
            val len = ch.toString().toByteArray(Charsets.UTF_8).size
            if (count + len > 74) {
                out.append("\r\n ")
                count = 1
            }
            out.append(ch)
            count += len
        }
        return out.toString()
    }
}
