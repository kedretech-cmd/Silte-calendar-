package com.silte.calendar.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Recurrence
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * A personal event. Field names follow the original app's JSON so backups stay compatible:
 * `dateKey` is the Silte date ("1448-5-20"), `reminderHour/Minute` is the event's time.
 */
@Entity(tableName = "events", indices = [Index("epochDay")])
data class EventEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val dateKey: String,
    val epochDay: Long,
    val isAllDay: Boolean = true,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,
    val recurrence: String = Recurrence.NONE.name,
    /** Minutes before the event to notify; -1 = no reminder. */
    val remindBefore: Int = 0,
    /** ARGB color, or null to use the theme's primary color. */
    val color: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val repeat: Recurrence get() = Recurrence.from(recurrence)

    /** Minute of the day the event happens; all-day events use [allDayMinute]. */
    fun minuteOfDay(allDayMinute: Int): Int =
        if (isAllDay || reminderHour == null) allDayMinute else reminderHour * 60 + (reminderMinute ?: 0)

    /** Stable positive int for notification and alarm IDs. */
    val notificationId: Int get() = id.hashCode() and 0x7FFFFFFF

    companion object {
        fun keyFor(epochDay: Long) = CalendarSystem.SILTE.fromEpochDay(epochDay).key
    }
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY epochDay, isAllDay DESC, reminderHour, reminderMinute")
    fun observeAll(): Flow<List<EventEntity>>

    @Query("SELECT * FROM events")
    suspend fun getAll(): List<EventEntity>

    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun get(id: String): EventEntity?

    @Upsert
    suspend fun upsert(event: EventEntity)

    @Upsert
    suspend fun upsertAll(events: List<EventEntity>)

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [EventEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun events(): EventDao
}
