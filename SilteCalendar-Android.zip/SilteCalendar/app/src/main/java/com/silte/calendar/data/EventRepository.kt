package com.silte.calendar.data

import kotlinx.coroutines.flow.Flow

/** An event on a concrete day (recurring events produce many occurrences). */
data class Occurrence(val epochDay: Long, val event: EventEntity)

class EventRepository(
    private val dao: EventDao,
    /** Called after any change so reminders and widgets stay in sync. */
    private val onChanged: suspend () -> Unit,
) {
    val events: Flow<List<EventEntity>> = dao.observeAll()

    suspend fun all(): List<EventEntity> = dao.getAll()
    suspend fun get(id: String): EventEntity? = dao.get(id)

    suspend fun save(event: EventEntity) {
        dao.upsert(event.copy(dateKey = EventEntity.keyFor(event.epochDay)))
        onChanged()
    }

    suspend fun delete(id: String) {
        dao.delete(id)
        onChanged()
    }

    /** Replaces or merges events from a backup; returns how many were imported. */
    suspend fun import(events: List<EventEntity>): Int {
        dao.upsertAll(events)
        onChanged()
        return events.size
    }

    companion object {
        /** Expands events (including recurring ones) into the inclusive range of days. */
        fun occurrences(events: List<EventEntity>, fromEpoch: Long, toEpoch: Long): Map<Long, List<EventEntity>> {
            val map = HashMap<Long, MutableList<EventEntity>>()
            for (e in events) {
                if (e.epochDay > toEpoch) continue
                val repeat = e.repeat
                if (repeat == com.silte.calendar.core.Recurrence.NONE) {
                    if (e.epochDay >= fromEpoch) map.getOrPut(e.epochDay) { mutableListOf() } += e
                    continue
                }
                var d = maxOf(fromEpoch, e.epochDay)
                while (d <= toEpoch) {
                    if (repeat.occursOn(e.epochDay, d)) map.getOrPut(d) { mutableListOf() } += e
                    d++
                }
            }
            map.values.forEach { list -> list.sortWith(compareBy({ !it.isAllDay }, { it.minuteOfDay(0) })) }
            return map
        }

        /** Chronological list of occurrences in the range. */
        fun agenda(events: List<EventEntity>, fromEpoch: Long, toEpoch: Long): List<Occurrence> =
            occurrences(events, fromEpoch, toEpoch).toSortedMap().flatMap { (day, list) -> list.map { Occurrence(day, it) } }
    }
}
