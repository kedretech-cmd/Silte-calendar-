package com.silte.calendar.data

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.silte.calendar.core.CalendarSystem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.ByteArrayInputStream
import java.io.File
import kotlin.coroutines.resume

/**
 * The previous version of this app (same package ID) was a Capacitor web app that kept
 * events and settings in the WebView's localStorage for the origin https://localhost.
 * After the update, that storage is still on the device; this reads it once and imports it,
 * so people upgrading do not lose their events.
 */
object LegacyImport {
    private const val ORIGIN = "https://localhost/"
    private val KEYS = listOf(
        "silte_ev", "silte_col", "silte_lang", "silte_theme", "silte_primary_cal", "silte_disp_greg",
        "silte_use_geez", "silte_show_public", "silte_show_orthodox", "silte_show_muslim",
        "silte_show_notification", "silte_onboarded",
    )

    /** Runs the import if it has not been done yet. Safe to call on every launch. */
    suspend fun runOnce(context: Context, settings: SettingsRepository, events: EventRepository) {
        if (settings.current().legacyImported) return
        val hasWebViewData = File(context.applicationInfo.dataDir, "app_webview").exists()
        val values = if (hasWebViewData) readLocalStorage(context) else null
        if (values != null) apply(values, settings, events)
        settings.update { it.copy(legacyImported = true) }
    }

    private suspend fun apply(v: Map<String, String?>, settings: SettingsRepository, events: EventRepository) {
        v["silte_ev"]?.let { raw ->
            runCatching {
                Backup.json.decodeFromString(ListSerializer(BackupEvent.serializer()), raw).mapNotNull(Backup::fromBackup)
            }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { events.import(it) }
        }
        val colors = v["silte_col"]?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }
        fun color(key: String): Int? = colors?.get(key)?.jsonPrimitive?.content?.let { runCatching { Color.parseColor(it) }.getOrNull() }
        fun bool(key: String): Boolean? = v[key]?.toBooleanStrictOrNull()

        settings.update { s ->
            s.copy(
                themeMode = when (v["silte_theme"]) { "light" -> ThemeMode.LIGHT; "dark" -> ThemeMode.DARK; else -> s.themeMode },
                primaryCalendar = v["silte_primary_cal"]?.let(CalendarSystem::fromKey) ?: s.primaryCalendar,
                showGregorian = bool("silte_disp_greg") ?: s.showGregorian,
                useGeez = bool("silte_use_geez") ?: s.useGeez,
                showPublic = bool("silte_show_public") ?: s.showPublic,
                showOrthodox = bool("silte_show_orthodox") ?: s.showOrthodox,
                showMuslim = bool("silte_show_muslim") ?: s.showMuslim,
                dailyDigest = bool("silte_show_notification") ?: s.dailyDigest,
                onboarded = bool("silte_onboarded") ?: s.onboarded,
                primaryColor = color("primary") ?: s.primaryColor,
                weekendColor = color("weekendColor") ?: s.weekendColor,
            )
        }
        v["silte_lang"]?.takeIf { it == "am" || it == "en" }?.let { lang ->
            withContext(Dispatchers.Main) {
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang))
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun readLocalStorage(context: Context): Map<String, String?>? = withContext(Dispatchers.Main) {
        withTimeoutOrNull(6_000) {
            suspendCancellableCoroutine { cont ->
                val webView = runCatching { WebView(context) }.getOrNull()
                if (webView == null) {
                    cont.resume(null)
                    return@suspendCancellableCoroutine
                }
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.webViewClient = object : WebViewClient() {
                    // Serve an empty page for the old origin without touching the network.
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                        WebResourceResponse("text/html", "utf-8", ByteArrayInputStream("<html></html>".toByteArray()))

                    override fun onPageFinished(view: WebView, url: String) {
                        val keys = KEYS.joinToString(",") { "'$it'" }
                        val js = "(function(){var o={};[$keys].forEach(function(k){o[k]=localStorage.getItem(k)});return JSON.stringify(o);})()"
                        view.evaluateJavascript(js) { result ->
                            val map = runCatching {
                                // The result is a JSON string literal containing our JSON object.
                                val inner = Json.parseToJsonElement(result).jsonPrimitive.content
                                (Json.parseToJsonElement(inner) as JsonObject).mapValues { (_, el) ->
                                    el.jsonPrimitive.takeIf { it.isString }?.content
                                }
                            }.getOrNull()
                            view.destroy()
                            if (cont.isActive) cont.resume(map)
                        }
                    }
                }
                cont.invokeOnCancellation { webView.post { runCatching { webView.destroy() } } }
                webView.loadUrl(ORIGIN)
            }
        }
    }
}
