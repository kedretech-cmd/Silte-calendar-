package com.silte.calendar.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.HolidayFilter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Every user preference. Defaults match the original app. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val primaryCalendar: CalendarSystem = CalendarSystem.SILTE,
    val showGregorian: Boolean = true,
    val useGeez: Boolean = false,
    val showPublic: Boolean = true,
    val showOrthodox: Boolean = true,
    val showMuslim: Boolean = true,
    /** Silent morning summary with today's date in all three calendars and any holidays. */
    val dailyDigest: Boolean = true,
    val digestMinute: Int = 8 * 60,
    /** Default reminder for new events, in minutes before; -1 = none. */
    val defaultRemindBefore: Int = 15,
    val primaryColor: Int = DEFAULT_PRIMARY,
    val weekendColor: Int = DEFAULT_WEEKEND,
    /** Material You wallpaper colors (Android 12+), overriding [primaryColor]. */
    val dynamicColor: Boolean = false,
    val onboarded: Boolean = false,
    val legacyImported: Boolean = false,
) {
    val holidayFilter: HolidayFilter get() = HolidayFilter(showPublic, showOrthodox, showMuslim)

    companion object {
        const val DEFAULT_PRIMARY = 0xFF0175C2.toInt()
        const val DEFAULT_WEEKEND = 0xFFD94040.toInt()
        val PRIMARY_PRESETS: List<Int> = listOf(
            0xFF0175C2, 0xFF6366F1, 0xFF10B981, 0xFFF59E0B,
            0xFFF43F5E, 0xFF8B5CF6, 0xFF0F766E, 0xFF92400E,
        ).map { it.toInt() }
        val WEEKEND_PRESETS: List<Int> = listOf(
            0xFFD94040, 0xFFEF4444, 0xFFF97316, 0xFFDC2626, 0xFFE11D48, 0xFFB91C1C,
        ).map { it.toInt() }
    }
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

class SettingsRepository(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme")
        val primaryCal = stringPreferencesKey("primary_cal")
        val showGreg = booleanPreferencesKey("disp_greg")
        val geez = booleanPreferencesKey("use_geez")
        val pub = booleanPreferencesKey("show_public")
        val orth = booleanPreferencesKey("show_orthodox")
        val mus = booleanPreferencesKey("show_muslim")
        val digest = booleanPreferencesKey("show_notification")
        val digestMinute = intPreferencesKey("digest_minute")
        val remindBefore = intPreferencesKey("remind_before")
        val primaryColor = intPreferencesKey("primary_color")
        val weekendColor = intPreferencesKey("weekend_color")
        val dynamic = booleanPreferencesKey("dynamic_color")
        val onboarded = booleanPreferencesKey("onboarded")
        val legacy = booleanPreferencesKey("legacy_imported")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map(::read).distinctUntilChanged()

    suspend fun current(): AppSettings = settings.first()

    /** Atomically reads, transforms and writes all settings. */
    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            themeMode = p[K.theme]?.let { v -> ThemeMode.entries.firstOrNull { it.name == v } } ?: d.themeMode,
            primaryCalendar = p[K.primaryCal]?.let(CalendarSystem::fromKey) ?: d.primaryCalendar,
            showGregorian = p[K.showGreg] ?: d.showGregorian,
            useGeez = p[K.geez] ?: d.useGeez,
            showPublic = p[K.pub] ?: d.showPublic,
            showOrthodox = p[K.orth] ?: d.showOrthodox,
            showMuslim = p[K.mus] ?: d.showMuslim,
            dailyDigest = p[K.digest] ?: d.dailyDigest,
            digestMinute = p[K.digestMinute] ?: d.digestMinute,
            defaultRemindBefore = p[K.remindBefore] ?: d.defaultRemindBefore,
            primaryColor = p[K.primaryColor] ?: d.primaryColor,
            weekendColor = p[K.weekendColor] ?: d.weekendColor,
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            onboarded = p[K.onboarded] ?: d.onboarded,
            legacyImported = p[K.legacy] ?: d.legacyImported,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.theme] = s.themeMode.name
        p[K.primaryCal] = s.primaryCalendar.name
        p[K.showGreg] = s.showGregorian
        p[K.geez] = s.useGeez
        p[K.pub] = s.showPublic
        p[K.orth] = s.showOrthodox
        p[K.mus] = s.showMuslim
        p[K.digest] = s.dailyDigest
        p[K.digestMinute] = s.digestMinute
        p[K.remindBefore] = s.defaultRemindBefore
        p[K.primaryColor] = s.primaryColor
        p[K.weekendColor] = s.weekendColor
        p[K.dynamic] = s.dynamicColor
        p[K.onboarded] = s.onboarded
        p[K.legacy] = s.legacyImported
    }
}
