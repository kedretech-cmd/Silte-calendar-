package com.silte.calendar.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.silte.calendar.MainActivity
import com.silte.calendar.R
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Holiday
import com.silte.calendar.core.Names
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity

object Notifications {
    const val CHANNEL_REMINDERS = "reminders"
    const val CHANNEL_DIGEST = "daily_digest"
    private const val DIGEST_ID = 1

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(
                    CHANNEL_REMINDERS, context.getString(R.string.channel_reminders), NotificationManager.IMPORTANCE_HIGH,
                ).apply { description = context.getString(R.string.channel_reminders_desc) },
                NotificationChannel(
                    CHANNEL_DIGEST, context.getString(R.string.channel_digest), NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = context.getString(R.string.channel_digest_desc)
                    setShowBadge(false)
                },
            ),
        )
    }

    fun canPost(context: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun isAmharic(context: Context): Boolean = context.resources.configuration.locales[0].language == "am"

    private fun openApp(context: Context, epochDay: Long?, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (epochDay != null) putExtra(MainActivity.EXTRA_EPOCH_DAY, epochDay)
        }
        return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    @Suppress("MissingPermission")
    fun showEventReminder(context: Context, event: EventEntity, epochDay: Long, is24h: Boolean) {
        if (!canPost(context)) return
        val when_ = if (event.isAllDay || event.reminderHour == null) {
            context.getString(R.string.all_day)
        } else {
            Fmt.time(event.reminderHour, event.reminderMinute ?: 0, is24h)
        }
        val date = Fmt.date(CalendarSystem.SILTE, epochDay)
        val snooze = PendingIntent.getBroadcast(
            context, event.notificationId,
            Intent(context, AlarmReceiver::class.java).apply {
                action = AlarmReceiver.ACTION_SNOOZE
                putExtra(AlarmReceiver.EXTRA_EVENT_ID, event.id)
                putExtra(AlarmReceiver.EXTRA_EPOCH_DAY, epochDay)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val body = listOf("$when_ · $date", event.description).filter { it.isNotBlank() }.joinToString("\n")
        val n = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_stat_calendar)
            .setContentTitle(event.title)
            .setContentText("$when_ · $date")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(event.color ?: AppSettings.DEFAULT_PRIMARY)
            .setAutoCancel(true)
            .setContentIntent(openApp(context, epochDay, event.notificationId))
            .addAction(0, context.getString(R.string.action_snooze), snooze)
            .build()
        NotificationManagerCompat.from(context).notify(event.notificationId, n)
    }

    /** The morning summary promised by the original app: today in all three calendars + holidays. */
    @Suppress("MissingPermission")
    fun showDigest(context: Context, epochDay: Long, holidays: List<Holiday>, events: List<EventEntity>, settings: AppSettings) {
        if (!canPost(context)) return
        val am = isAmharic(context)
        val geez = settings.useGeez
        val silte = Fmt.date(CalendarSystem.SILTE, epochDay, geez)
        val title = "${Names.silteWeekdays[weekdayOf(epochDay)]} · $silte"
        val lines = buildList {
            add(Fmt.date(CalendarSystem.ETHIOPIAN, epochDay, geez) + "  ·  " + Fmt.date(CalendarSystem.GREGORIAN, epochDay))
            holidays.forEach { add("🎉 " + it.name(am)) }
            if (events.isNotEmpty()) add(context.getString(R.string.digest_events, events.size) + ": " + events.joinToString { it.title })
        }
        val style = NotificationCompat.InboxStyle().also { s -> lines.forEach(s::addLine) }
        val n = NotificationCompat.Builder(context, CHANNEL_DIGEST)
            .setSmallIcon(R.drawable.ic_stat_calendar)
            .setContentTitle(title)
            .setContentText(lines.drop(1).firstOrNull() ?: lines.first())
            .setStyle(style)
            .setSilent(true)
            .setColor(settings.primaryColor)
            .setAutoCancel(true)
            .setContentIntent(openApp(context, epochDay, DIGEST_ID))
            .build()
        NotificationManagerCompat.from(context).notify(DIGEST_ID, n)
    }
}
