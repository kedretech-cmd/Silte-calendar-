package com.silte.calendar.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.format.DateFormat
import androidx.core.content.edit
import com.silte.calendar.SilteApp
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity
import com.silte.calendar.data.EventRepository
import com.silte.calendar.widget.WidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/** Schedules event reminders, the daily digest and the midnight widget refresh with AlarmManager. */
class ReminderScheduler(private val context: Context) {

    private val alarms = context.getSystemService(AlarmManager::class.java)
    private val prefs = context.getSharedPreferences("scheduled_alarms", Context.MODE_PRIVATE)

    fun canScheduleExact(): Boolean = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()

    /** Cancels every alarm scheduled before and schedules the next reminder of each event. */
    fun rescheduleAll(events: List<EventEntity>, settings: AppSettings) {
        val previous = prefs.getStringSet(KEY_IDS, emptySet()).orEmpty()
        previous.forEach { id -> alarms.cancel(eventIntent(id, 0L, create = true)) }

        val scheduled = mutableSetOf<String>()
        for (e in events) if (schedule(e, settings)) scheduled += e.id
        prefs.edit { putStringSet(KEY_IDS, scheduled) }

        scheduleDigest(settings)
        scheduleMidnightRefresh()
    }

    /** Schedules the next reminder for [event]; returns false if there is none. */
    fun schedule(event: EventEntity, settings: AppSettings, afterMillis: Long = System.currentTimeMillis()): Boolean {
        if (event.remindBefore < 0) return false
        val next = nextTrigger(event, settings.digestMinute, afterMillis) ?: return false
        setAlarm(next.first, eventIntent(event.id, next.second, create = true))
        return true
    }

    /** (trigger time in millis, occurrence epoch day) of the next reminder after [afterMillis]. */
    private fun nextTrigger(event: EventEntity, allDayMinute: Int, afterMillis: Long): Pair<Long, Long>? {
        val rule = event.repeat
        // Start one day before today so a "1 day before" reminder for tomorrow is still found.
        var from = maxOf(event.epochDay, todayEpochDay() - 1)
        for (attempt in 0 until 3) {
            val day = rule.nextOccurrence(event.epochDay, from) ?: return null
            val minute = event.minuteOfDay(allDayMinute)
            val trigger = millisAt(day, minute) - event.remindBefore * 60_000L
            if (trigger > afterMillis) return trigger to day
            from = day + 1
        }
        return null
    }

    fun scheduleDigest(settings: AppSettings) {
        val pi = broadcast(AlarmReceiver.ACTION_DIGEST, REQ_DIGEST)
        alarms.cancel(pi)
        if (!settings.dailyDigest) return
        var day = todayEpochDay()
        if (millisAt(day, settings.digestMinute) <= System.currentTimeMillis()) day++
        // The digest is informational, so an inexact alarm is fine and saves battery.
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millisAt(day, settings.digestMinute), pi)
    }

    /** Refreshes widgets right after midnight so "today" is always correct. */
    fun scheduleMidnightRefresh() {
        val pi = broadcast(AlarmReceiver.ACTION_MIDNIGHT, REQ_MIDNIGHT)
        alarms.cancel(pi)
        alarms.set(AlarmManager.RTC, millisAt(todayEpochDay() + 1, 0) + 5_000, pi)
    }

    fun snooze(eventId: String, epochDay: Long, minutes: Int = 10) {
        setAlarm(System.currentTimeMillis() + minutes * 60_000L, eventIntent(eventId, epochDay, create = true, snooze = true))
    }

    private fun setAlarm(at: Long, pi: PendingIntent) {
        if (canScheduleExact()) {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun eventIntent(id: String, epochDay: Long, create: Boolean, snooze: Boolean = false): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = if (snooze) AlarmReceiver.ACTION_SNOOZED_EVENT else AlarmReceiver.ACTION_EVENT
            // A distinct data URI per event keeps PendingIntents separate.
            data = android.net.Uri.parse("silte://event/$id")
            putExtra(AlarmReceiver.EXTRA_EVENT_ID, id)
            putExtra(AlarmReceiver.EXTRA_EPOCH_DAY, epochDay)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(context, id.hashCode(), intent, flags)
    }

    private fun broadcast(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context, requestCode,
            Intent(context, AlarmReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun millisAt(epochDay: Long, minuteOfDay: Int): Long =
        LocalDate.ofEpochDay(epochDay)
            .atTime(LocalTime.of(minuteOfDay / 60, minuteOfDay % 60))
            .atZone(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()

    private companion object {
        const val KEY_IDS = "ids"
        const val REQ_DIGEST = 9001
        const val REQ_MIDNIGHT = 9002
    }
}

/** Handles all alarms. Work runs off the main thread via goAsync(). */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as SilteApp
        val c = app.container
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                val settings = c.settings.current()
                val is24h = DateFormat.is24HourFormat(context)
                when (intent.action) {
                    ACTION_EVENT, ACTION_SNOOZED_EVENT -> {
                        val id = intent.getStringExtra(EXTRA_EVENT_ID) ?: return@launch
                        val day = intent.getLongExtra(EXTRA_EPOCH_DAY, todayEpochDay())
                        val event = c.events.get(id) ?: return@launch
                        Notifications.showEventReminder(context, event, day, is24h)
                        // Recurring events: queue the next occurrence.
                        if (intent.action == ACTION_EVENT) c.scheduler.schedule(event, settings)
                    }
                    ACTION_SNOOZE -> {
                        val id = intent.getStringExtra(EXTRA_EVENT_ID) ?: return@launch
                        val day = intent.getLongExtra(EXTRA_EPOCH_DAY, todayEpochDay())
                        androidx.core.app.NotificationManagerCompat.from(context).cancel(id.hashCode() and 0x7FFFFFFF)
                        c.scheduler.snooze(id, day)
                    }
                    ACTION_DIGEST -> {
                        val today = todayEpochDay()
                        val holidays = c.holidays.on(today, settings.holidayFilter)
                        val todays = EventRepository.occurrences(c.events.all(), today, today)[today].orEmpty()
                        Notifications.showDigest(context, today, holidays, todays, settings)
                        c.scheduler.scheduleDigest(settings)
                    }
                    ACTION_MIDNIGHT -> {
                        WidgetUpdater.updateAll(context)
                        c.scheduler.scheduleMidnightRefresh()
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_EVENT = "com.silte.calendar.EVENT"
        const val ACTION_SNOOZED_EVENT = "com.silte.calendar.SNOOZED_EVENT"
        const val ACTION_SNOOZE = "com.silte.calendar.SNOOZE"
        const val ACTION_DIGEST = "com.silte.calendar.DIGEST"
        const val ACTION_MIDNIGHT = "com.silte.calendar.MIDNIGHT"
        const val EXTRA_EVENT_ID = "event_id"
        const val EXTRA_EPOCH_DAY = "epoch_day"
    }
}

/** Alarms are cleared on reboot and invalid after clock/time-zone changes, so reschedule them. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val c = (context.applicationContext as SilteApp).container
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                c.syncAll()
            } finally {
                pending.finish()
            }
        }
    }
}
