package com.silte.calendar.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.silte.calendar.AppContainer
import com.silte.calendar.core.HolidayProvider
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.Backup
import com.silte.calendar.data.EventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val c: AppContainer) : ViewModel() {

    /** Null until DataStore has loaded; the splash screen stays up until then. */
    val settings: StateFlow<AppSettings?> =
        c.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val events: StateFlow<List<EventEntity>> =
        c.events.events.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val holidays: HolidayProvider get() = c.holidays

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { c.settings.update(transform) }
    }

    fun saveEvent(event: EventEntity) {
        viewModelScope.launch { c.events.save(event) }
    }

    fun deleteEvent(id: String) {
        viewModelScope.launch { c.events.delete(id) }
    }

    suspend fun getEvent(id: String): EventEntity? = c.events.get(id)

    suspend fun backupJson(): String = withContext(Dispatchers.Default) { Backup.encode(c.events.all()) }

    /** Imports a backup from this app or the original one; returns the number of events. */
    suspend fun restore(text: String): Int = withContext(Dispatchers.Default) { c.events.import(Backup.decode(text)) }

    suspend fun icsExport(): String = withContext(Dispatchers.Default) { Backup.toIcs(c.events.all()) }

    fun canScheduleExactAlarms() = c.scheduler.canScheduleExact()

    fun resync() {
        viewModelScope.launch { c.syncAll() }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { MainViewModel(container) }
        }
    }
}
