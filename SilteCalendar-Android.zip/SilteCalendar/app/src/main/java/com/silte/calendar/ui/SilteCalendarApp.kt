package com.silte.calendar.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.silte.calendar.R
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventRepository
import com.silte.calendar.notify.Notifications
import com.silte.calendar.ui.convert.ConvertScreen
import com.silte.calendar.ui.editor.EventEditorScreen
import com.silte.calendar.ui.events.EventsScreen
import com.silte.calendar.ui.holidays.HolidaysScreen
import com.silte.calendar.ui.month.MonthScreen
import com.silte.calendar.ui.onboarding.OnboardingScreen
import com.silte.calendar.ui.settings.AboutPage
import com.silte.calendar.ui.settings.BackupPage
import com.silte.calendar.ui.settings.ColorsPage
import com.silte.calendar.ui.settings.ExportPage
import com.silte.calendar.ui.settings.NotificationsPage
import com.silte.calendar.ui.settings.SettingsScreen
import com.silte.calendar.ui.settings.WidgetsPage

private data class Tab(val route: String, val icon: ImageVector, val label: Int)

private val TABS = listOf(
    Tab("month", Icons.Rounded.CalendarMonth, R.string.tab_month),
    Tab("events", Icons.Rounded.Event, R.string.tab_events),
    Tab("holidays", Icons.Rounded.Celebration, R.string.tab_holidays),
    Tab("convert", Icons.Rounded.SwapHoriz, R.string.tab_convert),
    Tab("settings", Icons.Rounded.Settings, R.string.tab_settings),
)

/** A request coming from a notification, widget or shortcut. */
sealed interface LaunchRequest {
    data class OpenDay(val epochDay: Long) : LaunchRequest
    data class NewEvent(val epochDay: Long) : LaunchRequest
    data object Convert : LaunchRequest
    data object Events : LaunchRequest
}

fun NavHostController.openTab(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true
    restoreState = true
}

fun NavHostController.openEditor(id: String? = null, day: Long = todayEpochDay()) =
    navigate("editor?id=${id.orEmpty()}&day=$day")

@Composable
fun SilteCalendarApp(
    vm: MainViewModel,
    settings: AppSettings,
    launchRequest: LaunchRequest?,
    onLaunchHandled: () -> Unit,
    jumpRequest: Long?,
    onJump: (Long?) -> Unit,
) {
    val events by vm.events.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBottomBar = TABS.any { it.route == route }
    val update: ((AppSettings) -> AppSettings) -> Unit = vm::updateSettings
    val context = LocalContext.current

    if (!settings.onboarded) {
        OnboardingScreen(settings, update)
        return
    }

    LaunchedEffect(launchRequest) {
        when (val r = launchRequest) {
            is LaunchRequest.OpenDay -> { nav.openTab("month"); onJump(r.epochDay) }
            is LaunchRequest.NewEvent -> nav.openEditor(day = r.epochDay)
            LaunchRequest.Convert -> nav.openTab("convert")
            LaunchRequest.Events -> nav.openTab("events")
            null -> return@LaunchedEffect
        }
        onLaunchHandled()
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                NavigationBar {
                    TABS.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { nav.openTab(tab.route) },
                            icon = { Icon(tab.icon, null) },
                            label = { Text(stringResource(tab.label), maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "month",
            modifier = Modifier.padding(padding).consumeWindowInsets(padding),
        ) {
            composable("month") {
                MonthScreen(
                    settings = settings, events = events, holidays = vm.holidays,
                    jumpRequest = jumpRequest, onJumpConsumed = { onJump(null) },
                    onAddEvent = { nav.openEditor(day = it) },
                    onOpenEvent = { nav.openEditor(id = it) },
                )
            }
            composable("events") {
                EventsScreen(
                    settings = settings, events = events,
                    onAdd = { nav.openEditor() },
                    onOpen = { nav.openEditor(id = it) },
                    onDelete = { vm.deleteEvent(it.id) },
                    onRestore = { vm.saveEvent(it) },
                )
            }
            composable("holidays") {
                HolidaysScreen(settings, vm.holidays, onOpenDay = { day -> nav.openTab("month"); onJump(day) })
            }
            composable("convert") {
                ConvertScreen(settings, onAddEvent = { nav.openEditor(day = it) })
            }
            composable("settings") {
                SettingsScreen(settings, update, navigate = { nav.navigate(it) })
            }
            composable("settings/colors") { ColorsPage(settings, update, onBack = { nav.popBackStack() }) }
            composable("settings/notifications") {
                NotificationsPage(
                    settings, update,
                    canScheduleExact = vm::canScheduleExactAlarms,
                    onTestDigest = {
                        val today = todayEpochDay()
                        Notifications.showDigest(
                            context, today, vm.holidays.on(today, settings.holidayFilter),
                            EventRepository.occurrences(events, today, today)[today].orEmpty(), settings,
                        )
                    },
                    onBack = { nav.popBackStack() },
                )
            }
            composable("settings/widgets") { WidgetsPage(onBack = { nav.popBackStack() }) }
            composable("settings/backup") {
                BackupPage(events.size, vm::backupJson, vm::restore, onBack = { nav.popBackStack() })
            }
            composable("settings/export") { ExportPage(events, vm::icsExport, onBack = { nav.popBackStack() }) }
            composable("settings/about") { AboutPage(onBack = { nav.popBackStack() }) }
            composable(
                "editor?id={id}&day={day}",
                arguments = listOf(
                    navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("day") { type = NavType.LongType; defaultValue = -1L },
                ),
            ) { entry ->
                val id = entry.arguments?.getString("id")?.takeIf { it.isNotBlank() }
                val day = entry.arguments?.getLong("day")?.takeIf { it >= 0 } ?: todayEpochDay()
                EventEditorScreen(
                    settings = settings, eventId = id, initialDay = day,
                    loadEvent = vm::getEvent,
                    onSave = vm::saveEvent,
                    onDelete = vm::deleteEvent,
                    onClose = { nav.popBackStack() },
                )
            }
        }
    }
}
