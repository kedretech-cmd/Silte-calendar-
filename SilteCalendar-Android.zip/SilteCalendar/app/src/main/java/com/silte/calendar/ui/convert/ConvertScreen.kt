package com.silte.calendar.ui.convert

import android.content.ClipData
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipEntry
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.silte.calendar.R
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Names
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.ui.components.AccentCard
import kotlinx.coroutines.launch

@Composable
fun ConvertScreen(settings: AppSettings, onAddEvent: (Long) -> Unit) {
    var source by rememberSaveable { mutableStateOf(CalendarSystem.SILTE) }
    val start = remember { source.today() }
    var dayText by rememberSaveable { mutableStateOf(start.day.toString()) }
    var month by rememberSaveable { mutableStateOf(start.month) }
    var yearText by rememberSaveable { mutableStateOf(start.year.toString()) }

    val y = yearText.toIntOrNull()
    val d = dayText.toIntOrNull()
    val m = month.coerceIn(1, source.monthsInYear())
    val error: String? = when {
        y == null || d == null || y <= 0 || d <= 0 -> stringResource(R.string.convert_error_numbers)
        y > 9999 -> stringResource(R.string.convert_error_numbers)
        d > source.daysInMonth(y, m) -> stringResource(
            R.string.convert_error_days, Names.monthName(source, m), y, source.daysInMonth(y, m),
        )
        else -> null
    }
    val epoch: Long? = if (error == null) source.toEpochDay(y!!, m, d!!) else null

    fun setFrom(system: CalendarSystem, epochDay: Long) {
        val ymd = system.fromEpochDay(epochDay)
        source = system
        dayText = ymd.day.toString()
        month = ymd.month
        yearText = ymd.year.toString()
    }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_convert)) }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(top = padding.calculateTopPadding()).verticalScroll(rememberScrollState()).imePadding()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(stringResource(R.string.convert_intro), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                val options = listOf(
                    CalendarSystem.SILTE to R.string.cal_silte,
                    CalendarSystem.ETHIOPIAN to R.string.cal_ethiopian,
                    CalendarSystem.GREGORIAN to R.string.cal_gregorian,
                )
                options.forEachIndexed { i, (system, label) ->
                    SegmentedButton(
                        selected = source == system,
                        onClick = {
                            // Like the original app: switching source converts the entered date.
                            if (epoch != null) setFrom(system, epoch) else source = system
                            if (month > system.monthsInYear()) month = system.monthsInYear()
                        },
                        shape = SegmentedButtonDefaults.itemShape(i, options.size),
                    ) { Text(stringResource(label), maxLines = 1) }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                OutlinedTextField(
                    value = dayText, onValueChange = { dayText = it.filter(Char::isDigit).take(2) },
                    label = { Text(stringResource(R.string.day)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                MonthDropdown(source, m, onSelect = { month = it }, modifier = Modifier.weight(2f))
                OutlinedTextField(
                    value = yearText, onValueChange = { yearText = it.filter(Char::isDigit).take(4) },
                    label = { Text(stringResource(R.string.year)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1.4f),
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { setFrom(source, todayEpochDay()) }) {
                    Icon(Icons.Rounded.Today, null)
                    Spacer(Modifier.padding(4.dp))
                    Text(stringResource(R.string.today))
                }
                if (epoch != null) {
                    FilledTonalButton(onClick = { onAddEvent(epoch) }) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.padding(4.dp))
                        Text(stringResource(R.string.add_event))
                    }
                }
            }

            if (error != null) {
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                    Text("⚠️ $error", color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp))
                }
            } else if (epoch != null) {
                val geez = settings.useGeez
                val wd = weekdayOf(epoch)
                val diff = epoch - todayEpochDay()
                Text(stringResource(R.string.convert_results).uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                ResultCard("🌙 " + stringResource(R.string.cal_silte), Fmt.date(CalendarSystem.SILTE, epoch, geez), MaterialTheme.colorScheme.primary)
                ResultCard("🇪🇹 " + stringResource(R.string.cal_ethiopian), Fmt.date(CalendarSystem.ETHIOPIAN, epoch, geez), Color(0xFF10B981))
                ResultCard("🌍 " + stringResource(R.string.cal_gregorian), Fmt.date(CalendarSystem.GREGORIAN, epoch), Color(0xFFF59E0B))
                ResultCard(
                    "📅 " + stringResource(R.string.weekday),
                    "${Names.silteWeekdays[wd]} (${Names.gregorianWeekday(wd)})",
                    Color(0xFF8B5CF6),
                )
                Text(
                    when {
                        diff == 0L -> stringResource(R.string.today)
                        diff > 0 -> stringResource(R.string.in_days, diff.toInt())
                        else -> stringResource(R.string.days_ago, (-diff).toInt())
                    },
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MonthDropdown(system: CalendarSystem, month: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier) {
        OutlinedTextField(
            value = "$month · ${Names.monthName(system, month)}",
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text(stringResource(R.string.month)) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (1..system.monthsInYear()).forEach { m ->
                DropdownMenuItem(
                    text = { Text("$m · ${Names.monthName(system, m)}") },
                    onClick = { onSelect(m); expanded = false },
                )
            }
        }
    }
}

@Composable
private fun ResultCard(label: String, value: String, accent: Color) {
    val clipboard = LocalClipboard.current
    val scope = rememberCoroutineScope()
    AccentCard(accent = accent) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { scope.launch { clipboard.setClipEntry(ClipEntry(ClipData.newPlainText(label, value))) } }) {
                Icon(Icons.Rounded.ContentCopy, stringResource(R.string.copy))
            }
        }
    }
}
