package com.silte.calendar.ui.editor

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Notes
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.EventRepeat
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.silte.calendar.R
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Names
import com.silte.calendar.core.Recurrence
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity
import com.silte.calendar.notify.Notifications
import com.silte.calendar.ui.components.ChoiceDialog
import com.silte.calendar.ui.components.ColorSwatch
import com.silte.calendar.ui.month.MonthGridView
import com.silte.calendar.ui.month.WeekdayHeader
import com.silte.calendar.ui.theme.SilteColors

val REMINDER_OPTIONS = listOf(-1, 0, 5, 10, 15, 30, 60, 120, 1440)

@Composable
fun reminderLabel(minutes: Int): String = when {
    minutes < 0 -> stringResource(R.string.remind_none)
    minutes == 0 -> stringResource(R.string.remind_at_time)
    minutes % 1440 == 0 -> stringResource(R.string.remind_days, minutes / 1440)
    minutes % 60 == 0 -> stringResource(R.string.remind_hours, minutes / 60)
    else -> stringResource(R.string.remind_minutes, minutes)
}

@Composable
fun recurrenceLabel(r: Recurrence): String = stringResource(
    when (r) {
        Recurrence.NONE -> R.string.repeat_none
        Recurrence.DAILY -> R.string.repeat_daily
        Recurrence.WEEKLY -> R.string.repeat_weekly
        Recurrence.MONTHLY -> R.string.repeat_monthly
        Recurrence.YEARLY -> R.string.repeat_yearly
    },
)

@Composable
fun EventEditorScreen(
    settings: AppSettings,
    eventId: String?,
    initialDay: Long,
    loadEvent: suspend (String) -> EventEntity?,
    onSave: (EventEntity) -> Unit,
    onDelete: (String) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    var loaded by remember { mutableStateOf<EventEntity?>(null) }
    var ready by rememberSaveable { mutableStateOf(eventId == null) }

    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var day by rememberSaveable { mutableStateOf(initialDay) }
    var allDay by rememberSaveable { mutableStateOf(true) }
    var hour by rememberSaveable { mutableStateOf(8) }
    var minute by rememberSaveable { mutableStateOf(0) }
    var remind by rememberSaveable { mutableStateOf(settings.defaultRemindBefore) }
    var repeat by rememberSaveable { mutableStateOf(Recurrence.NONE) }
    var color by rememberSaveable { mutableStateOf<Int?>(null) }
    var titleError by remember { mutableStateOf(false) }

    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var showRemind by remember { mutableStateOf(false) }
    var showRepeat by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(eventId) {
        if (eventId != null && !ready) {
            loadEvent(eventId)?.let { e ->
                loaded = e
                title = e.title
                description = e.description
                day = e.epochDay
                allDay = e.isAllDay
                hour = e.reminderHour ?: 8
                minute = e.reminderMinute ?: 0
                remind = e.remindBefore
                repeat = e.repeat
                color = e.color
            }
            ready = true
        } else if (eventId != null && loaded == null) {
            loaded = loadEvent(eventId)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun save() {
        if (title.isBlank()) {
            titleError = true
            return
        }
        val base = loaded ?: EventEntity(title = title, dateKey = "", epochDay = day)
        onSave(
            base.copy(
                title = title.trim(),
                description = description.trim(),
                epochDay = day,
                dateKey = EventEntity.keyFor(day),
                isAllDay = allDay,
                reminderHour = if (allDay) null else hour,
                reminderMinute = if (allDay) null else minute,
                recurrence = repeat.name,
                remindBefore = remind,
                color = color,
            ),
        )
        if (remind >= 0 && Build.VERSION.SDK_INT >= 33 && !Notifications.canPost(context)) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        onClose()
    }

    val is24h = android.text.format.DateFormat.is24HourFormat(context)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(if (eventId == null) R.string.new_event else R.string.edit_event)) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, stringResource(R.string.cancel)) } },
                actions = {
                    if (eventId != null) {
                        IconButton(onClick = {
                            val time = if (allDay) context.getString(R.string.all_day) else Fmt.time(hour, minute, is24h)
                            val text = buildString {
                                appendLine(title)
                                appendLine(Fmt.date(CalendarSystem.SILTE, day) + " (" + Fmt.date(CalendarSystem.GREGORIAN, day) + ")")
                                appendLine(time)
                                if (description.isNotBlank()) appendLine(description)
                            }
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_SUBJECT, "Silte Calendar: $title")
                                .putExtra(Intent.EXTRA_TEXT, text)
                            context.startActivity(Intent.createChooser(send, null))
                        }) { Icon(Icons.Rounded.Share, stringResource(R.string.share)) }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, stringResource(R.string.delete)) }
                    }
                    Button(onClick = ::save, modifier = Modifier.padding(end = 8.dp), enabled = ready) { Text(stringResource(R.string.save)) }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).imePadding().verticalScroll(rememberScrollState()),
        ) {
            TextField(
                value = title,
                onValueChange = { title = it; titleError = false },
                placeholder = { Text(stringResource(R.string.event_title_hint), style = MaterialTheme.typography.headlineSmall) },
                textStyle = MaterialTheme.typography.headlineSmall,
                isError = titleError,
                supportingText = { if (titleError) Text(stringResource(R.string.title_required)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    errorContainerColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp),
            )
            HorizontalDivider()

            EditorRow(Icons.Rounded.CalendarMonth, onClick = { showDate = true }) {
                Column {
                    Text(Names.silteWeekdays[weekdayOf(day)] + " · " + Fmt.date(CalendarSystem.SILTE, day, settings.useGeez), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        Fmt.date(CalendarSystem.ETHIOPIAN, day) + " · " + Fmt.date(CalendarSystem.GREGORIAN, day),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            EditorRow(Icons.Rounded.AccessTime, onClick = { allDay = !allDay }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.all_day), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Switch(checked = allDay, onCheckedChange = { allDay = it })
                }
            }
            if (!allDay) {
                EditorRow(null, onClick = { showTime = true }) {
                    Text(Fmt.time(hour, minute, is24h), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
            HorizontalDivider()
            EditorRow(Icons.Rounded.NotificationsActive, onClick = { showRemind = true }) {
                Column {
                    Text(reminderLabel(remind), style = MaterialTheme.typography.bodyLarge)
                    if (allDay && remind >= 0) {
                        Text(
                            stringResource(R.string.all_day_reminder_hint, Fmt.time(settings.digestMinute / 60, settings.digestMinute % 60, is24h)),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            EditorRow(Icons.Rounded.EventRepeat, onClick = { showRepeat = true }) {
                Text(recurrenceLabel(repeat), style = MaterialTheme.typography.bodyLarge)
            }
            EditorRow(Icons.Rounded.Palette, onClick = null) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ColorSwatch(MaterialTheme.colorScheme.primary, selected = color == null, onClick = { color = null }, size = 32)
                    SilteColors.EventPalette.forEach { c ->
                        ColorSwatch(Color(c), selected = color == c, onClick = { color = c }, size = 32)
                    }
                }
            }
            HorizontalDivider()
            EditorRow(Icons.AutoMirrored.Rounded.Notes, onClick = null) {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text(stringResource(R.string.description_hint)) },
                    minLines = 3,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (showDate) {
        DatePickerDialog(settings, day, onPick = { day = it; showDate = false }, onDismiss = { showDate = false })
    }
    if (showTime) {
        val state = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = is24h)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = { TextButton(onClick = { hour = state.hour; minute = state.minute; showTime = false }) { Text(stringResource(R.string.ok)) } },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text(stringResource(R.string.cancel)) } },
            text = { TimePicker(state = state) },
        )
    }
    if (showRemind) {
        ChoiceDialog(
            title = stringResource(R.string.reminder),
            options = REMINDER_OPTIONS.map { it to reminderLabel(it) },
            selected = remind, onSelect = { remind = it }, onDismiss = { showRemind = false },
        )
    }
    if (showRepeat) {
        ChoiceDialog(
            title = stringResource(R.string.repeat),
            options = Recurrence.entries.map { it to recurrenceLabel(it) },
            selected = repeat, onSelect = { repeat = it }, onDismiss = { showRepeat = false },
        )
    }
    if (confirmDelete && eventId != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_event_title)) },
            text = { Text(title) },
            confirmButton = { TextButton(onClick = { onDelete(eventId); onClose() }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun EditorRow(icon: ImageVector?, onClick: (() -> Unit)?, content: @Composable () -> Unit) {
    val rowModifier = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Row(rowModifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Spacer(Modifier.width(24.dp))
        }
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) { content() }
    }
}

/** Date picker that uses the app's own month grid, in the user's primary calendar. */
@Composable
fun DatePickerDialog(settings: AppSettings, initial: Long, onPick: (Long) -> Unit, onDismiss: () -> Unit) {
    val system = settings.primaryCalendar
    var month by remember { mutableStateOf(CalMonth.containing(system, initial)) }
    var selected by remember { mutableStateOf(initial) }
    val today = remember { com.silte.calendar.core.todayEpochDay() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onPick(selected) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
        title = {
            Column {
                Text(Fmt.date(system, selected, settings.useGeez), style = MaterialTheme.typography.titleLarge)
                val other = if (system == CalendarSystem.GREGORIAN) CalendarSystem.SILTE else CalendarSystem.GREGORIAN
                Text(Fmt.date(other, selected), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = month.plus(-1) }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, stringResource(R.string.previous_month)) }
                    Text(Fmt.monthTitle(month, settings.useGeez), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    IconButton(onClick = { month = month.plus(1) }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, stringResource(R.string.next_month)) }
                }
                WeekdayHeader(system)
                MonthGridView(
                    month = month, settings = settings, today = today, selected = selected,
                    eventColors = emptyMap(), holidays = emptyMap(), compact = true,
                    onDayClick = { cell ->
                        selected = cell.epochDay
                        if (!cell.inMonth) month = CalMonth.containing(system, cell.epochDay)
                    },
                )
            }
        },
    )
}
