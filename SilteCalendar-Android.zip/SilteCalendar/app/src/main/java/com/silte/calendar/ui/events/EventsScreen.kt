package com.silte.calendar.ui.events

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.automirrored.rounded.EventNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.silte.calendar.R
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Names
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity
import com.silte.calendar.data.EventRepository
import com.silte.calendar.data.Occurrence
import com.silte.calendar.ui.components.EmptyState
import com.silte.calendar.ui.month.EventCard
import com.silte.calendar.ui.month.rememberToday
import kotlinx.coroutines.launch

private enum class EventFilter { UPCOMING, ALL, PAST }

@Composable
fun EventsScreen(
    settings: AppSettings,
    events: List<EventEntity>,
    onAdd: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (EventEntity) -> Unit,
    onRestore: (EventEntity) -> Unit,
) {
    val today by rememberToday()
    var filter by rememberSaveable { mutableStateOf(EventFilter.UPCOMING) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val deletedMsg = stringResource(R.string.event_deleted)
    val undo = stringResource(R.string.undo)

    val occurrences: List<Occurrence> = remember(events, filter, query, today) {
        val q = query.trim()
        val matching = if (q.isEmpty()) events else events.filter {
            it.title.contains(q, ignoreCase = true) || it.description.contains(q, ignoreCase = true)
        }
        when (filter) {
            // Recurring events are expanded over the coming year.
            EventFilter.UPCOMING -> EventRepository.agenda(matching, today, today + 365)
            EventFilter.ALL -> matching.sortedBy { it.epochDay }.map { Occurrence(it.epochDay, it) }
            EventFilter.PAST -> matching.filter { it.epochDay < today }.sortedByDescending { it.epochDay }.map { Occurrence(it.epochDay, it) }
        }
    }
    val grouped = remember(occurrences) { occurrences.groupBy { it.epochDay } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text(stringResource(R.string.search_events)) },
                            singleLine = true,
                            shape = MaterialTheme.shapes.extraLarge,
                            modifier = Modifier.fillMaxWidth().padding(end = 8.dp),
                        )
                    } else {
                        Text(stringResource(R.string.tab_events))
                    }
                },
                actions = {
                    IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                        Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, stringResource(R.string.search_events))
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Icon(Icons.Rounded.Add, stringResource(R.string.add_event)) }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(filter == EventFilter.UPCOMING, { filter = EventFilter.UPCOMING }, { Text(stringResource(R.string.filter_upcoming)) })
                FilterChip(filter == EventFilter.ALL, { filter = EventFilter.ALL }, { Text(stringResource(R.string.filter_all)) })
                FilterChip(filter == EventFilter.PAST, { filter = EventFilter.PAST }, { Text(stringResource(R.string.filter_past)) })
            }

            if (occurrences.isEmpty()) {
                EmptyState(
                    icon = Icons.AutoMirrored.Rounded.EventNote,
                    title = stringResource(if (query.isBlank()) R.string.no_events_title else R.string.no_results),
                    body = stringResource(R.string.no_events_body),
                )
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), modifier = Modifier.fillMaxSize()) {
                    grouped.forEach { (day, list) ->
                        stickyHeader(key = "d-$day") { DayHeader(day, today, settings) }
                        items(list, key = { "${it.event.id}-${it.epochDay}" }) { occ ->
                            SwipeToDelete(
                                onDelete = {
                                    onDelete(occ.event)
                                    scope.launch {
                                        val r = snackbar.showSnackbar(deletedMsg, actionLabel = undo, duration = SnackbarDuration.Short)
                                        if (r == SnackbarResult.ActionPerformed) onRestore(occ.event)
                                    }
                                },
                                modifier = Modifier.animateItem().padding(horizontal = 16.dp, vertical = 4.dp),
                            ) {
                                EventCard(occ.event, settings, onClick = { onOpen(occ.event.id) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayHeader(epochDay: Long, today: Long, settings: AppSettings) {
    val relative = when (val d = epochDay - today) {
        0L -> stringResource(R.string.today)
        1L -> stringResource(R.string.tomorrow)
        -1L -> stringResource(R.string.yesterday)
        in 2..Long.MAX_VALUE -> stringResource(R.string.in_days, d.toInt())
        else -> stringResource(R.string.days_ago, (-d).toInt())
    }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "${Names.silteWeekdays[weekdayOf(epochDay)]} · ${Fmt.date(settings.primaryCalendar, epochDay, settings.useGeez)}",
                style = MaterialTheme.typography.titleSmall,
            )
            val secondary = if (settings.primaryCalendar == CalendarSystem.GREGORIAN) CalendarSystem.SILTE else CalendarSystem.GREGORIAN
            Text(Fmt.date(secondary, epochDay), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(relative, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SwipeToDelete(onDelete: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val state = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value == SwipeToDismissBoxValue.EndToStart) {
                onDelete()
                true
            } else {
                false
            }
        },
    )
    SwipeToDismissBox(
        state = state,
        modifier = modifier,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            Box(
                Modifier.fillMaxSize().clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.errorContainer).padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Icon(Icons.Rounded.Delete, stringResource(R.string.delete), tint = MaterialTheme.colorScheme.onErrorContainer)
            }
        },
    ) { content() }
}
