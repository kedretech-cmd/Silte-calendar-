package com.silte.calendar.ui.holidays

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.silte.calendar.R
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Holiday
import com.silte.calendar.core.HolidayFilter
import com.silte.calendar.core.HolidayProvider
import com.silte.calendar.core.Names
import com.silte.calendar.data.AppSettings
import com.silte.calendar.ui.components.EmptyState
import com.silte.calendar.ui.components.holidayColor
import com.silte.calendar.ui.components.holidayTypeLabel
import com.silte.calendar.ui.month.isAmharic
import com.silte.calendar.ui.month.rememberToday

@Composable
fun HolidaysScreen(settings: AppSettings, holidays: HolidayProvider, onOpenDay: (Long) -> Unit) {
    val system = settings.primaryCalendar
    val today by rememberToday()
    var year by rememberSaveable(system) { mutableIntStateOf(system.fromEpochDay(today).year) }
    var filter by remember(settings.holidayFilter) { mutableStateOf(settings.holidayFilter) }

    val list: List<Holiday> = remember(system, year, filter) {
        val from = CalMonth(system, year, 1).firstEpochDay
        val to = CalMonth(system, year, system.monthsInYear()).lastEpochDay
        holidays.inRange(from, to, filter).values.flatten().sortedBy { it.epochDay }
    }
    val next = list.firstOrNull { it.epochDay >= today }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_holidays)) }) }) { padding ->
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 24.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { year-- }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, stringResource(R.string.previous_year)) }
                    Text(
                        Fmt.num(year, settings.useGeez && system != CalendarSystem.GREGORIAN) + if (system == CalendarSystem.ETHIOPIAN) " ዓ.ም" else "",
                        style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { year++ }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, stringResource(R.string.next_year)) }
                }
            }
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(filter.public, { filter = filter.copy(public = !filter.public) }, { Text(stringResource(R.string.filter_public)) })
                    FilterChip(filter.orthodox, { filter = filter.copy(orthodox = !filter.orthodox) }, { Text(stringResource(R.string.filter_orthodox)) })
                    FilterChip(filter.muslim, { filter = filter.copy(muslim = !filter.muslim) }, { Text(stringResource(R.string.filter_muslim)) })
                }
            }
            if (next != null) {
                item { NextHolidayCard(next, today, settings, onClick = { onOpenDay(next.epochDay) }) }
            }
            if (list.isEmpty()) {
                item {
                    EmptyState(Icons.Rounded.Celebration, stringResource(R.string.no_holidays_title), stringResource(R.string.no_holidays_body))
                }
            }
            items(list, key = { "${it.epochDay}-${it.nameEn}" }) { h ->
                HolidayRow(h, today, settings, onClick = { onOpenDay(h.epochDay) })
            }
        }
    }
}

@Composable
private fun NextHolidayCard(h: Holiday, today: Long, settings: AppSettings, onClick: () -> Unit) {
    val am = isAmharic()
    val days = (h.epochDay - today).toInt()
    Surface(
        onClick = onClick,
        modifier = Modifier.padding(16.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.secondaryContainer,
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(stringResource(R.string.next_holiday), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Spacer(Modifier.height(4.dp))
            Text(h.name(am), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Text(
                Fmt.date(settings.primaryCalendar, h.epochDay, settings.useGeez),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (days == 0) stringResource(R.string.today) else stringResource(R.string.in_days, days),
                style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun HolidayRow(h: Holiday, today: Long, settings: AppSettings, onClick: () -> Unit) {
    val am = isAmharic()
    val system = settings.primaryCalendar
    val ymd = system.fromEpochDay(h.epochDay)
    val past = h.epochDay < today
    val color = holidayColor(h.type)
    Surface(
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            // Date badge
            Surface(shape = RoundedCornerShape(12.dp), color = color.copy(alpha = 0.15f), modifier = Modifier.size(width = 64.dp, height = 60.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(Names.monthName(system, ymd.month, short = true), style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
                    Text(
                        Fmt.num(ymd.day, settings.useGeez && system != CalendarSystem.GREGORIAN),
                        style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold,
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    h.name(am), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = if (past) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                )
                val other = if (system == CalendarSystem.GREGORIAN) CalendarSystem.SILTE else CalendarSystem.GREGORIAN
                Text(Fmt.date(other, h.epochDay), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(holidayTypeLabel(h.type, h.dayOff), style = MaterialTheme.typography.labelSmall, color = color)
                    if (h.approximate) Text(stringResource(R.string.holiday_approx), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Suppress("unused")
private fun HolidayFilter.any() = public || orthodox || muslim
