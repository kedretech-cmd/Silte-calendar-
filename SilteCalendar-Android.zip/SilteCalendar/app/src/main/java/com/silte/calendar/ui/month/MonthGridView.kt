package com.silte.calendar.ui.month

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.DayCell
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Holiday
import com.silte.calendar.core.MonthGrid
import com.silte.calendar.core.Names
import com.silte.calendar.data.AppSettings
import com.silte.calendar.ui.theme.LocalCalendarColors

@Composable
fun WeekdayHeader(system: CalendarSystem, modifier: Modifier = Modifier) {
    val weekend = LocalCalendarColors.current.weekend
    Row(modifier.fillMaxWidth()) {
        Names.weekdayHeaders(system).forEachIndexed { i, name ->
            Text(
                text = name,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium,
                color = if (i == 0 || i == 6) weekend else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * The month grid. [eventColors] maps epoch day → dot colors (null = theme primary).
 */
@Composable
fun MonthGridView(
    month: CalMonth,
    settings: AppSettings,
    today: Long,
    selected: Long?,
    eventColors: Map<Long, List<Int?>>,
    holidays: Map<Long, List<Holiday>>,
    onDayClick: (DayCell) -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    val cells = remember(month) { MonthGrid.build(month) }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 4.dp)) {
        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 4.dp)) {
                week.forEach { cell ->
                    DayCellView(
                        cell = cell,
                        system = month.system,
                        settings = settings,
                        isToday = cell.epochDay == today,
                        isSelected = cell.epochDay == selected,
                        dots = eventColors[cell.epochDay].orEmpty(),
                        holidays = holidays[cell.epochDay].orEmpty(),
                        compact = compact,
                        onClick = { onDayClick(cell) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun DayCellView(
    cell: DayCell,
    system: CalendarSystem,
    settings: AppSettings,
    isToday: Boolean,
    isSelected: Boolean,
    dots: List<Int?>,
    holidays: List<Holiday>,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val cal = LocalCalendarColors.current
    val isWeekend = cell.weekday == 0 || cell.weekday == 6
    val isDayOff = holidays.any { it.dayOff }

    val background by animateColorAsState(
        when {
            isToday -> scheme.primary
            isSelected -> scheme.primaryContainer
            else -> Color.Transparent
        },
        label = "cellBackground",
    )
    val mainColor = when {
        isToday -> scheme.onPrimary
        isWeekend || isDayOff -> cal.weekend
        isSelected -> scheme.onPrimaryContainer
        else -> scheme.onSurface
    }
    val subColor = if (isToday) scheme.onPrimary.copy(alpha = 0.8f) else scheme.onSurfaceVariant

    // Primary number in the center; secondary calendars in the corners (same layout as the original app).
    val geezAllowed = settings.useGeez && system != CalendarSystem.GREGORIAN
    val mainLabel = Fmt.num(cell.primary.day, geezAllowed)
    val bottomLabel: Int = when (system) {
        CalendarSystem.SILTE -> CalendarSystem.ETHIOPIAN.fromEpochDay(cell.epochDay).day
        CalendarSystem.ETHIOPIAN -> CalendarSystem.SILTE.fromEpochDay(cell.epochDay).day
        CalendarSystem.GREGORIAN -> CalendarSystem.SILTE.fromEpochDay(cell.epochDay).day
    }
    val topLabel: Int? = when {
        system == CalendarSystem.GREGORIAN -> CalendarSystem.ETHIOPIAN.fromEpochDay(cell.epochDay).day
        settings.showGregorian -> CalendarSystem.GREGORIAN.fromEpochDay(cell.epochDay).day
        else -> null
    }
    val description = Fmt.date(system, cell.primary) + if (holidays.isNotEmpty()) ", " + holidays.joinToString { it.nameEn } else ""

    Box(
        modifier
            .height(if (compact) 44.dp else 60.dp)
            .clip(RoundedCornerShape(if (compact) 10.dp else 14.dp))
            .background(background)
            .then(
                if (isSelected && isToday) Modifier.border(2.dp, scheme.onSurface.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                else if (isSelected) Modifier.border(1.5.dp, scheme.primary, RoundedCornerShape(14.dp))
                else Modifier,
            )
            .clickable(onClick = onClick)
            .alpha(if (cell.inMonth) 1f else 0.35f)
            .semantics {
                contentDescription = description
                this.selected = isSelected
            },
    ) {
        if (topLabel != null && !compact) {
            Text(
                topLabel.toString(), color = subColor, fontSize = 9.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 5.dp, top = 3.dp),
            )
        }
        Text(
            mainLabel,
            color = mainColor,
            fontSize = if (compact) 14.sp else if (geezAllowed) 17.sp else 18.sp,
            fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Center).padding(bottom = if (compact) 0.dp else 4.dp),
        )
        if (!compact) {
            Text(
                bottomLabel.toString(), color = subColor, fontSize = 9.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 5.dp, bottom = 3.dp),
            )
        }
        // Indicator dots: personal events, then holidays.
        val dotColors = buildList {
            dots.take(3).forEach { add(if (isToday) scheme.onPrimary else it?.let(::Color) ?: scheme.primary) }
            holidays.firstOrNull()?.let { h ->
                add(
                    when (h.type) {
                        com.silte.calendar.core.HolidayType.PUBLIC -> cal.holiday
                        com.silte.calendar.core.HolidayType.ORTHODOX -> cal.orthodox
                        com.silte.calendar.core.HolidayType.MUSLIM -> cal.muslim
                    },
                )
            }
        }
        if (dotColors.isNotEmpty()) {
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = if (compact) 3.dp else 5.dp),
                horizontalArrangement = Arrangement.spacedBy(2.5.dp),
            ) {
                dotColors.forEach { c -> Box(Modifier.size(if (compact) 4.dp else 5.dp).clip(CircleShape).background(c)) }
            }
        }
    }
}
