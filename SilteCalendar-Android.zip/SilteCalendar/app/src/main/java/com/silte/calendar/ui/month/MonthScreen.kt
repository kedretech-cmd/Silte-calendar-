package com.silte.calendar.ui.month

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.EventRepeat
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.silte.calendar.R
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Holiday
import com.silte.calendar.core.HolidayProvider
import com.silte.calendar.core.Names
import com.silte.calendar.core.Recurrence
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity
import com.silte.calendar.data.EventRepository
import com.silte.calendar.ui.components.AccentCard
import com.silte.calendar.ui.components.DatePill
import com.silte.calendar.ui.components.holidayColor
import com.silte.calendar.ui.components.holidayTypeLabel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

private const val PAGE_COUNT = 10_000 * 13

@Composable
fun isAmharic(): Boolean = LocalConfiguration.current.locales[0].language == "am"

/** Today's epoch day, updated automatically at midnight. */
@Composable
fun rememberToday(): State<Long> = produceState(todayEpochDay()) {
    while (true) {
        val now = LocalDateTime.now()
        val nextMidnight = LocalDate.now().plusDays(1).atStartOfDay()
        delay(Duration.between(now, nextMidnight).toMillis() + 1_000)
        value = todayEpochDay()
    }
}

@Composable
fun MonthScreen(
    settings: AppSettings,
    events: List<EventEntity>,
    holidays: HolidayProvider,
    jumpRequest: Long?,
    onJumpConsumed: () -> Unit,
    onAddEvent: (epochDay: Long) -> Unit,
    onOpenEvent: (id: String) -> Unit,
) {
    val system = settings.primaryCalendar
    val today by rememberToday()
    var selected by rememberSaveable { mutableLongStateOf(todayEpochDay()) }
    var showPicker by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Re-create the pager when the primary calendar changes (page indices differ per calendar).
    key(system) {
        val pagerState = rememberPagerState(initialPage = CalMonth.containing(system, selected).index) { PAGE_COUNT }
        val currentMonth = CalMonth.fromIndex(system, pagerState.currentPage)

        fun goTo(epochDay: Long, animate: Boolean = true) {
            selected = epochDay
            val page = CalMonth.containing(system, epochDay).index
            scope.launch { if (animate) pagerState.animateScrollToPage(page) else pagerState.scrollToPage(page) }
        }

        LaunchedEffect(jumpRequest) {
            if (jumpRequest != null) {
                goTo(jumpRequest, animate = false)
                onJumpConsumed()
            }
        }
        // When the user swipes to another month, keep the selection inside it.
        LaunchedEffect(pagerState.settledPage) {
            val m = CalMonth.fromIndex(system, pagerState.settledPage)
            if (selected !in m.firstEpochDay..m.lastEpochDay) {
                selected = if (today in m.firstEpochDay..m.lastEpochDay) today else m.firstEpochDay
            }
        }

        val selectedEvents = remember(events, selected) { EventRepository.occurrences(events, selected, selected)[selected].orEmpty() }
        val selectedHolidays = remember(selected, settings.holidayFilter) { holidays.on(selected, settings.holidayFilter) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(stringResource(R.string.app_title), style = MaterialTheme.typography.titleLarge)
                        }
                    },
                    actions = {
                        IconButton(onClick = { goTo(today) }) {
                            Icon(Icons.Rounded.Today, contentDescription = stringResource(R.string.today))
                        }
                    },
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { onAddEvent(selected) },
                    icon = { Icon(Icons.Rounded.Add, null) },
                    text = { Text(stringResource(R.string.add_event)) },
                )
            },
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 96.dp),
            ) {
                item(key = "hero") {
                    TodayHero(today, settings, holidays.on(today, settings.holidayFilter), onClick = { goTo(today) })
                }
                item(key = "header") {
                    MonthHeader(
                        month = currentMonth,
                        settings = settings,
                        onPrev = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } },
                        onNext = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } },
                        onTitleClick = { showPicker = true },
                    )
                }
                item(key = "banners") {
                    Column(Modifier.animateContentSize()) {
                        if (system == CalendarSystem.SILTE && currentMonth.month == 1) NewYearBanner()
                        if (system != CalendarSystem.GREGORIAN && currentMonth.month == 13) {
                            val leap = system.isLeapYear(currentMonth.year)
                            DatePill(
                                stringResource(if (leap) R.string.pagume_leap else R.string.pagume_normal),
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                                container = MaterialTheme.colorScheme.tertiaryContainer,
                            )
                        }
                    }
                }
                item(key = "weekdays") {
                    WeekdayHeader(system, Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
                item(key = "pager") {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxWidth().animateContentSize(),
                        verticalAlignment = Alignment.Top,
                        beyondViewportPageCount = 1,
                    ) { page ->
                        val month = remember(page) { CalMonth.fromIndex(system, page) }
                        val range = month.firstEpochDay - 7..month.lastEpochDay + 7
                        val dots = remember(events, month) {
                            EventRepository.occurrences(events, range.first, range.last).mapValues { (_, list) -> list.map { it.color } }
                        }
                        val monthHolidays = remember(month, settings.holidayFilter) {
                            holidays.inRange(range.first, range.last, settings.holidayFilter)
                        }
                        MonthGridView(
                            month = month,
                            settings = settings,
                            today = today,
                            selected = selected,
                            eventColors = dots,
                            holidays = monthHolidays,
                            onDayClick = { cell -> if (cell.inMonth) selected = cell.epochDay else goTo(cell.epochDay) },
                            modifier = Modifier.padding(horizontal = 12.dp),
                        )
                    }
                }
                item(key = "dayHeader") {
                    SelectedDayHeader(selected, settings, Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp))
                }
                items(selectedHolidays, key = { "h-" + it.nameEn }) { h ->
                    HolidayCard(h, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                items(selectedEvents, key = { "e-" + it.id }) { e ->
                    EventCard(e, settings, onClick = { onOpenEvent(e.id) }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                if (selectedEvents.isEmpty()) {
                    item(key = "empty") {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                stringResource(R.string.no_events_day),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = { onAddEvent(selected) }) { Text(stringResource(R.string.add_event)) }
                        }
                    }
                }
            }
        }

        if (showPicker) {
            MonthPickerSheet(
                current = currentMonth,
                settings = settings,
                onPick = { m ->
                    showPicker = false
                    scope.launch { pagerState.animateScrollToPage(m.index) }
                },
                onDismiss = { showPicker = false },
            )
        }
    }
}

@Composable
private fun TodayHero(today: Long, settings: AppSettings, holidays: List<Holiday>, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val silte = CalendarSystem.SILTE.fromEpochDay(today)
    val geez = settings.useGeez
    val am = isAmharic()
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        onClick = onClick,
        color = scheme.primary,
    ) {
        Row(
            Modifier
                .background(Brush.linearGradient(listOf(scheme.primary, scheme.tertiary)))
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
                Text(
                    Fmt.num(silte.day, geez), color = scheme.onPrimary,
                    fontSize = if (geez) 40.sp else 48.sp, fontWeight = FontWeight.Bold, lineHeight = 52.sp,
                )
                Text(Names.silteMonths[silte.month - 1], color = scheme.onPrimary, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "${Names.silteWeekdays[weekdayOf(today)]} · ${Names.gregorianWeekday(weekdayOf(today))}",
                    color = scheme.onPrimary.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge,
                )
                Text(
                    Fmt.date(CalendarSystem.SILTE, silte, geez), color = scheme.onPrimary,
                    style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    Fmt.date(CalendarSystem.ETHIOPIAN, today, geez) + "  •  " + Fmt.date(CalendarSystem.GREGORIAN, today),
                    color = scheme.onPrimary.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall,
                )
                holidays.firstOrNull()?.let {
                    Text("🎉 " + it.name(am), color = scheme.onPrimary, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun MonthHeader(month: CalMonth, settings: AppSettings, onPrev: () -> Unit, onNext: () -> Unit, onTitleClick: () -> Unit) {
    val others = CalendarSystem.entries.filter { it != month.system }
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPrev) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, stringResource(R.string.previous_month)) }
        Column(
            Modifier.weight(1f).clip(MaterialTheme.shapes.medium).clickable(onClick = onTitleClick).padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Fmt.monthTitle(month, settings.useGeez), style = MaterialTheme.typography.headlineSmall)
                Icon(Icons.Rounded.ArrowDropDown, null)
            }
            Text(
                others.joinToString("  /  ") { Fmt.span(month, it) },
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center, maxLines = 2,
            )
        }
        IconButton(onClick = onNext) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, stringResource(R.string.next_month)) }
    }
}

@Composable
private fun NewYearBanner() {
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.tertiaryContainer,
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎉 ላጅሲ አይዶ ሀበይ በወገሬት አጄጄሙ!", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
            Text("ለአዲሱ አመት እንኳን አደረሳችሁ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }
    }
}

@Composable
private fun SelectedDayHeader(epochDay: Long, settings: AppSettings, modifier: Modifier = Modifier) {
    val system = settings.primaryCalendar
    val wd = weekdayOf(epochDay)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "${Names.silteWeekdays[wd]} · ${Fmt.date(system, epochDay, settings.useGeez)}",
            style = MaterialTheme.typography.titleMedium,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CalendarSystem.entries.filter { it != system }.forEach { other ->
                val icon = when (other) {
                    CalendarSystem.SILTE -> "🌙"
                    CalendarSystem.ETHIOPIAN -> "🗓"
                    CalendarSystem.GREGORIAN -> "🌍"
                }
                DatePill("$icon ${Fmt.date(other, epochDay, settings.useGeez && other != CalendarSystem.GREGORIAN)}")
            }
        }
    }
}

@Composable
fun HolidayCard(h: Holiday, modifier: Modifier = Modifier) {
    val am = isAmharic()
    AccentCard(accent = holidayColor(h.type), modifier = modifier) {
        Column {
            Text("🎉 " + h.name(am), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            val secondary = if (am) h.nameEn else h.nameAm
            Text(secondary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                Text(holidayTypeLabel(h.type, h.dayOff), style = MaterialTheme.typography.labelSmall, color = holidayColor(h.type))
                if (h.approximate) {
                    Text(stringResource(R.string.holiday_approx), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun EventCard(e: EventEntity, settings: AppSettings, onClick: () -> Unit, modifier: Modifier = Modifier, dateLabel: String? = null) {
    val is24h = android.text.format.DateFormat.is24HourFormat(androidx.compose.ui.platform.LocalContext.current)
    val time = if (e.isAllDay || e.reminderHour == null) stringResource(R.string.all_day) else Fmt.time(e.reminderHour, e.reminderMinute ?: 0, is24h)
    AccentCard(accent = e.color?.let { androidx.compose.ui.graphics.Color(it) } ?: MaterialTheme.colorScheme.primary, modifier = modifier, onClick = onClick) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (e.repeat != Recurrence.NONE) {
                    Icon(Icons.Rounded.EventRepeat, stringResource(R.string.repeats), modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(
                listOfNotNull(dateLabel, time).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (e.description.isNotBlank()) {
                Text(e.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun MonthPickerSheet(current: CalMonth, settings: AppSettings, onPick: (CalMonth) -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var year by remember { mutableStateOf(current.year) }
    val system = current.system
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { year-- }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, null) }
                Text(
                    Fmt.num(year, settings.useGeez && system != CalendarSystem.GREGORIAN) + if (system == CalendarSystem.ETHIOPIAN) " ዓ.ም" else "",
                    style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { year++ }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) }
            }
            Spacer(Modifier.height(12.dp))
            val months = (1..system.monthsInYear()).toList()
            months.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { m ->
                        val isCurrent = year == current.year && m == current.month
                        Surface(
                            onClick = { onPick(CalMonth(system, year, m)) },
                            shape = RoundedCornerShape(14.dp),
                            color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier.weight(1f).height(52.dp),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(
                                    Names.monthName(system, m, short = true), maxLines = 1,
                                    color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.labelLarge,
                                )
                                Text(
                                    m.toString(), style = MaterialTheme.typography.labelSmall,
                                    color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
