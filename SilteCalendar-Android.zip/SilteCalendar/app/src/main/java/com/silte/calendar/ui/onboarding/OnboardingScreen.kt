package com.silte.calendar.ui.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.silte.calendar.R
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.ThemeMode
import com.silte.calendar.ui.month.MonthGridView
import com.silte.calendar.ui.month.WeekdayHeader
import com.silte.calendar.ui.settings.calendarName
import com.silte.calendar.ui.settings.currentLanguage
import com.silte.calendar.ui.settings.setLanguage
import com.silte.calendar.ui.settings.themeName

private const val STEPS = 4

@Composable
fun OnboardingScreen(settings: AppSettings, update: ((AppSettings) -> AppSettings) -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(1) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun finish() {
        update { it.copy(onboarded = true) }
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                if (step > 1) {
                    IconButton(onClick = { step-- }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = ::finish) { Text(stringResource(R.string.skip)) }
            }
            LinearProgressIndicator(progress = { step / STEPS.toFloat() }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(24.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally { it * dir / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it * dir / 3 } + fadeOut())
                },
                modifier = Modifier.weight(1f),
                label = "onboarding",
            ) { s ->
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    when (s) {
                        1 -> {
                            Title("Select Language / ቋንቋ ይምረጡ", stringResource(R.string.onb_language_desc))
                            val lang = currentLanguage()
                            OptionCard("አማርኛ (Amharic)", null, lang == "am") { setLanguage("am") }
                            OptionCard("English", null, lang == "en") { setLanguage("en") }
                        }
                        2 -> {
                            Title(stringResource(R.string.pick_theme), stringResource(R.string.change_later))
                            OptionCard("☀️  " + themeName(ThemeMode.LIGHT), stringResource(R.string.theme_light_desc), settings.themeMode == ThemeMode.LIGHT) {
                                update { it.copy(themeMode = ThemeMode.LIGHT) }
                            }
                            OptionCard("🌙  " + themeName(ThemeMode.DARK), stringResource(R.string.theme_dark_desc), settings.themeMode == ThemeMode.DARK) {
                                update { it.copy(themeMode = ThemeMode.DARK) }
                            }
                            OptionCard("📱  " + themeName(ThemeMode.SYSTEM), stringResource(R.string.theme_system_desc), settings.themeMode == ThemeMode.SYSTEM) {
                                update { it.copy(themeMode = ThemeMode.SYSTEM) }
                            }
                        }
                        3 -> {
                            Title(stringResource(R.string.display_options), stringResource(R.string.select_preview))
                            ToggleCard(stringResource(R.string.display_gregorian), stringResource(R.string.display_gregorian_desc), settings.showGregorian) { v ->
                                update { it.copy(showGregorian = v) }
                            }
                            ToggleCard(stringResource(R.string.use_geez), stringResource(R.string.use_geez_desc), settings.useGeez) { v ->
                                update { it.copy(useGeez = v) }
                            }
                            Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    WeekdayHeader(CalendarSystem.SILTE)
                                    MonthGridView(
                                        month = CalMonth.containing(CalendarSystem.SILTE, todayEpochDay()),
                                        settings = settings.copy(primaryCalendar = CalendarSystem.SILTE),
                                        today = todayEpochDay(), selected = null,
                                        eventColors = emptyMap(), holidays = emptyMap(), onDayClick = {},
                                    )
                                }
                            }
                        }
                        else -> {
                            Title(stringResource(R.string.primary_calendar), stringResource(R.string.onb_calendar_desc))
                            listOf(
                                CalendarSystem.SILTE to "🌙",
                                CalendarSystem.ETHIOPIAN to "🇪🇹",
                                CalendarSystem.GREGORIAN to "🌍",
                            ).forEach { (system, icon) ->
                                OptionCard("$icon  " + calendarName(system), null, settings.primaryCalendar == system) {
                                    update { it.copy(primaryCalendar = system) }
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = { if (step < STEPS) step++ else finish() },
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp).height(52.dp),
            ) { Text(stringResource(if (step < STEPS) R.string.next else R.string.done)) }
        }
    }
}

@Composable
private fun Title(title: String, desc: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(desc, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun OptionCard(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ToggleCard(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Surface(
        onClick = { onChange(!checked) }, shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
