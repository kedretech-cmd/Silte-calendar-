package com.silte.calendar.ui.settings

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarViewMonth
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipEntry
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.silte.calendar.BuildConfig
import com.silte.calendar.R
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Names
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.Backup
import com.silte.calendar.data.EventEntity
import com.silte.calendar.notify.Notifications
import com.silte.calendar.ui.components.BackTopBar
import com.silte.calendar.ui.components.ChoiceDialog
import com.silte.calendar.ui.components.ColorSwatch
import com.silte.calendar.ui.components.RowDivider
import com.silte.calendar.ui.components.SectionCard
import com.silte.calendar.ui.components.SectionLabel
import com.silte.calendar.ui.components.SettingRow
import com.silte.calendar.ui.components.SwitchRow
import com.silte.calendar.ui.editor.REMINDER_OPTIONS
import com.silte.calendar.ui.editor.reminderLabel
import com.silte.calendar.ui.month.MonthGridView
import com.silte.calendar.ui.month.WeekdayHeader
import com.silte.calendar.ui.month.isAmharic
import com.silte.calendar.widget.AgendaWidgetReceiver
import com.silte.calendar.widget.MonthWidgetReceiver
import com.silte.calendar.widget.TodayWidgetReceiver
import kotlinx.coroutines.launch

// ───────────────────────────── Colors ─────────────────────────────

@Composable
fun ColorsPage(settings: AppSettings, update: ((AppSettings) -> AppSettings) -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { BackTopBar(stringResource(R.string.customize_colors), onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            Text(
                stringResource(R.string.colors_live), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp),
            )
            if (settings.dynamicColor) {
                Text(
                    stringResource(R.string.colors_dynamic_note), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
            // Live preview of the current month.
            Surface(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow,
            ) {
                val month = CalMonth.containing(settings.primaryCalendar, todayEpochDay())
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(Fmt.monthTitle(month, settings.useGeez), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp))
                    WeekdayHeader(settings.primaryCalendar)
                    MonthGridView(
                        month = month, settings = settings, today = todayEpochDay(), selected = null,
                        eventColors = emptyMap(), holidays = emptyMap(), compact = true, onDayClick = {},
                    )
                }
            }
            ColorSection(
                label = stringResource(R.string.primary_color),
                presets = AppSettings.PRIMARY_PRESETS, value = settings.primaryColor,
                onChange = { c -> update { it.copy(primaryColor = c) } },
            )
            ColorSection(
                label = stringResource(R.string.weekend_color),
                presets = AppSettings.WEEKEND_PRESETS, value = settings.weekendColor,
                onChange = { c -> update { it.copy(weekendColor = c) } },
            )
            OutlinedButton(
                onClick = { update { it.copy(primaryColor = AppSettings.DEFAULT_PRIMARY, weekendColor = AppSettings.DEFAULT_WEEKEND) } },
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
            ) { Text(stringResource(R.string.reset_defaults)) }
        }
    }
}

@Composable
private fun ColorSection(label: String, presets: List<Int>, value: Int, onChange: (Int) -> Unit) {
    SectionLabel(label)
    SectionCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                presets.forEach { c -> ColorSwatch(Color(c), selected = c == value, onClick = { onChange(c) }) }
            }
            Text(stringResource(R.string.custom_color), style = MaterialTheme.typography.labelLarge)
            // Custom color: a hue slider at a pleasant saturation/lightness.
            val hsl = remember(value) { FloatArray(3).also { androidx.core.graphics.ColorUtils.colorToHSL(value, it) } }
            var hue by remember(value) { mutableStateOf(hsl[0]) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(
                    value = hue, onValueChange = { hue = it }, valueRange = 0f..359f,
                    onValueChangeFinished = { onChange(Color.hsl(hue, 0.75f, 0.45f).toArgb()) },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.padding(6.dp))
                ColorSwatch(Color.hsl(hue, 0.75f, 0.45f), selected = false, onClick = { onChange(Color.hsl(hue, 0.75f, 0.45f).toArgb()) }, size = 32)
            }
        }
    }
}

// ───────────────────────────── Notifications ─────────────────────────────

@Composable
fun NotificationsPage(
    settings: AppSettings,
    update: ((AppSettings) -> AppSettings) -> Unit,
    canScheduleExact: () -> Boolean,
    onTestDigest: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var canPost by remember { mutableStateOf(Notifications.canPost(context)) }
    var exact by remember { mutableStateOf(canScheduleExact()) }
    var showTime by remember { mutableStateOf(false) }
    var showRemind by remember { mutableStateOf(false) }
    val is24h = android.text.format.DateFormat.is24HourFormat(context)

    // Re-check permissions when returning from system settings.
    LifecycleResumeEffect(Unit) {
        canPost = Notifications.canPost(context)
        exact = canScheduleExact()
        onPauseOrDispose { }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { canPost = it }

    Scaffold(topBar = { BackTopBar(stringResource(R.string.notifications), onBack) }) { padding ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 32.dp)) {
            if (!canPost) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.large,
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(stringResource(R.string.notif_permission_off), color = MaterialTheme.colorScheme.onErrorContainer)
                            Button(onClick = {
                                if (Build.VERSION.SDK_INT >= 33) {
                                    launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    context.startActivity(
                                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                                    )
                                }
                            }) { Text(stringResource(R.string.enable_notifications)) }
                        }
                    }
                }
            }
            item {
                SectionLabel(stringResource(R.string.daily_summary))
                SectionCard {
                    SwitchRow(
                        stringResource(R.string.show_holiday_notification), settings.dailyDigest, { v -> update { it.copy(dailyDigest = v) } },
                        icon = Icons.Rounded.NotificationsActive, subtitle = stringResource(R.string.daily_summary_desc),
                    )
                    RowDivider()
                    SettingRow(
                        stringResource(R.string.summary_time), Icons.Rounded.Schedule,
                        value = Fmt.time(settings.digestMinute / 60, settings.digestMinute % 60, is24h),
                        onClick = { showTime = true },
                    )
                    RowDivider()
                    SettingRow(stringResource(R.string.send_test), Icons.Rounded.Today, onClick = onTestDigest, showChevron = false)
                }
            }
            item {
                SectionLabel(stringResource(R.string.event_reminders))
                SectionCard {
                    SettingRow(
                        stringResource(R.string.default_reminder), Icons.Rounded.Alarm,
                        value = reminderLabel(settings.defaultRemindBefore), onClick = { showRemind = true },
                    )
                    if (Build.VERSION.SDK_INT >= 31 && !exact) {
                        RowDivider()
                        SettingRow(
                            stringResource(R.string.exact_alarms), Icons.Rounded.Schedule,
                            subtitle = stringResource(R.string.exact_alarms_desc),
                            onClick = {
                                context.startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")),
                                )
                            },
                        )
                    }
                }
            }
        }
    }

    if (showTime) {
        val state = rememberTimePickerState(settings.digestMinute / 60, settings.digestMinute % 60, is24h)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = {
                TextButton(onClick = {
                    update { it.copy(digestMinute = state.hour * 60 + state.minute) }
                    showTime = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text(stringResource(R.string.cancel)) } },
            text = { TimePicker(state = state) },
        )
    }
    if (showRemind) {
        ChoiceDialog(
            stringResource(R.string.default_reminder), REMINDER_OPTIONS.map { it to reminderLabel(it) },
            settings.defaultRemindBefore, { m -> update { it.copy(defaultRemindBefore = m) } }, { showRemind = false },
        )
    }
}

// ───────────────────────────── Widgets ─────────────────────────────

@Composable
fun WidgetsPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val manager = remember { AppWidgetManager.getInstance(context) }
    val canPin = remember { manager.isRequestPinAppWidgetSupported }
    fun pin(receiver: Class<*>) {
        manager.requestPinAppWidget(ComponentName(context, receiver), null, null)
    }
    Scaffold(topBar = { BackTopBar(stringResource(R.string.widget_options), onBack) }) { padding ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 32.dp)) {
            item {
                WidgetCard(Icons.Rounded.Today, R.string.widget_today_name, R.string.widget_today_desc, canPin) { pin(TodayWidgetReceiver::class.java) }
                WidgetCard(Icons.Rounded.CalendarViewMonth, R.string.widget_month_name, R.string.widget_month_desc, canPin) { pin(MonthWidgetReceiver::class.java) }
                WidgetCard(Icons.Rounded.ViewAgenda, R.string.widget_agenda_name, R.string.widget_agenda_desc, canPin) { pin(AgendaWidgetReceiver::class.java) }
            }
            item {
                SectionLabel(stringResource(R.string.widget_how_title))
                SectionCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(R.string.widget_step1, R.string.widget_step2, R.string.widget_step3, R.string.widget_step4).forEachIndexed { i, s ->
                            Text("${i + 1}. " + stringResource(s), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WidgetCard(icon: ImageVector, name: Int, desc: Int, canPin: Boolean, onAdd: () -> Unit) {
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.primaryContainer) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(12.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(stringResource(name), style = MaterialTheme.typography.titleSmall)
                Text(stringResource(desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (canPin) FilledTonalButton(onClick = onAdd) { Text(stringResource(R.string.add)) }
        }
    }
}

// ───────────────────────────── Backup / Restore ─────────────────────────────

@Composable
fun BackupPage(
    eventCount: Int,
    backupJson: suspend () -> String,
    restore: suspend (String) -> Int,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val savedMsg = stringResource(R.string.backup_saved)
    val failedMsg = stringResource(R.string.backup_failed)
    val restoredFmt = stringResource(R.string.restored_events)

    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = runCatching {
                val json = backupJson()
                context.contentResolver.openOutputStream(uri)!!.use { it.write(json.toByteArray()) }
            }.isSuccess
            snackbar.showSnackbar(if (ok) savedMsg else failedMsg)
        }
    }
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val result = runCatching {
                val text = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                restore(text)
            }
            snackbar.showSnackbar(result.map { restoredFmt.format(it) }.getOrDefault(failedMsg))
        }
    }

    Scaffold(topBar = { BackTopBar(stringResource(R.string.backup_restore), onBack) }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.backup_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stringResource(R.string.events_count, eventCount), style = MaterialTheme.typography.titleMedium)
            Button(onClick = { createDoc.launch("silte_calendar_backup.json") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.FileDownload, null)
                Spacer(Modifier.padding(4.dp))
                Text(stringResource(R.string.download_backup))
            }
            OutlinedButton(onClick = { openDoc.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.FileUpload, null)
                Spacer(Modifier.padding(4.dp))
                Text(stringResource(R.string.restore_backup))
            }
            Text(stringResource(R.string.restore_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ───────────────────────────── Export ─────────────────────────────

@Composable
fun ExportPage(events: List<EventEntity>, icsExport: suspend () -> String, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboard.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val savedMsg = stringResource(R.string.export_saved)
    val copiedMsg = stringResource(R.string.copied)
    var monthIndex by remember { mutableIntStateOf(CalMonth.containing(CalendarSystem.SILTE, todayEpochDay()).index) }
    val month = CalMonth.fromIndex(CalendarSystem.SILTE, monthIndex)
    val json = remember(month, events) { Backup.exportMonth(month, events) }

    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            runCatching { context.contentResolver.openOutputStream(uri)!!.use { it.write(json.toByteArray()) } }
            snackbar.showSnackbar(savedMsg)
        }
    }
    val saveIcs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/calendar")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                val ics = icsExport()
                context.contentResolver.openOutputStream(uri)!!.use { it.write(ics.toByteArray()) }
            }
            snackbar.showSnackbar(savedMsg)
        }
    }

    Scaffold(topBar = { BackTopBar(stringResource(R.string.export_calendar), onBack) }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SectionLabel(stringResource(R.string.export_ics_title))
            SectionCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.export_ics_desc), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { saveIcs.launch("silte_calendar.ics") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Event, null)
                        Spacer(Modifier.padding(4.dp))
                        Text(stringResource(R.string.export_ics))
                    }
                }
            }
            SectionLabel(stringResource(R.string.export_month_title))
            SectionCard {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { monthIndex-- }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, stringResource(R.string.previous_month)) }
                        Text(Fmt.monthTitle(month), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                        IconButton(onClick = { monthIndex++ }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, stringResource(R.string.next_month)) }
                    }
                    Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceContainerHighest) {
                        Text(
                            json, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp,
                            modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState())
                                .horizontalScroll(rememberScrollState()).padding(10.dp),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { saveJson.launch("silte_${Names.silteMonths[month.month - 1]}_${month.year}.json") }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.download_json))
                        }
                        OutlinedButton(onClick = {
                            scope.launch {
                                clipboard.setClipEntry(ClipEntry(ClipData.newPlainText("Silte Calendar", json)))
                                snackbar.showSnackbar(copiedMsg)
                            }
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.ContentCopy, null)
                            Spacer(Modifier.padding(4.dp))
                            Text(stringResource(R.string.copy))
                        }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ───────────────────────────── About ─────────────────────────────

@Composable
fun AboutPage(onBack: () -> Unit) {
    val am = isAmharic()
    val silte = CalendarSystem.SILTE
    val todaySilte = silte.today()
    val nextNewYear = silte.toEpochDay(todaySilte.year + 1, 1, 1)
    Scaffold(topBar = { BackTopBar(stringResource(R.string.about_title), onBack) }) { padding ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 32.dp)) {
            item {
                Surface(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("የስልጤ አያም ኢልቅ", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(stringResource(R.string.about_intro), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            item {
                SectionLabel(stringResource(R.string.about_key_facts))
                AboutFact("📅", stringResource(R.string.about_months_title), stringResource(R.string.about_months_body))
                AboutFact("🔄", stringResource(R.string.about_years_title), stringResource(R.string.about_years_body))
                AboutFact(
                    "🌱", stringResource(R.string.about_newyear_title),
                    stringResource(
                        R.string.about_newyear_body,
                        Fmt.date(CalendarSystem.ETHIOPIAN, nextNewYear), Fmt.date(CalendarSystem.GREGORIAN, nextNewYear), todaySilte.year + 1,
                    ),
                )
            }
            item {
                SectionLabel(stringResource(R.string.about_weekdays))
                SectionCard {
                    val amharicDays = listOf("እሁድ", "ሰኞ", "ማክሰኞ", "ረቡዕ", "ሐሙስ", "አርብ", "ቅዳሜ")
                    val silteFull = listOf("ግድርሰንበት", "ኡጠት", "መገርገበያ", "አርጴ", "ከምስ", "ጂማት", "አንሰንበት")
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        (0..6).forEach { i ->
                            Row {
                                Text((if (am) amharicDays[i] else Names.gregorianWeekday(i)), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text(silteFull[i], style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
            item { MonthChips(stringResource(R.string.about_silte_months), Names.silteMonths) }
            item { MonthChips(stringResource(R.string.about_eth_months), Names.ethiopianMonths) }
            item { MonthChips(stringResource(R.string.about_greg_months), (1..12).map { Names.gregorianMonth(it) }) }
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("የስልጤ ካላንደር መተግበሪያ", style = MaterialTheme.typography.titleSmall)
                    Text(stringResource(R.string.developer_credit), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(stringResource(R.string.version, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AboutFact(emoji: String, title: String, body: String) {
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("$emoji  $title", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun MonthChips(title: String, months: List<String>) {
    SectionLabel(title)
    FlowRow(
        Modifier.padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        months.forEachIndexed { i, m ->
            Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("${i + 1}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.padding(3.dp))
                    Text(m, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}
