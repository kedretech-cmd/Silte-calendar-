package com.silte.calendar.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.silte.calendar.R
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.ThemeMode
import com.silte.calendar.ui.components.ChoiceDialog
import com.silte.calendar.ui.components.RowDivider
import com.silte.calendar.ui.components.SectionCard
import com.silte.calendar.ui.components.SectionLabel
import com.silte.calendar.ui.components.SettingRow
import com.silte.calendar.ui.components.SwitchRow

const val PLAY_URL = "https://play.google.com/store/apps/details?id=com.silte.calendar"
const val SUPPORT_EMAIL = "kedretech@gmail.com"

/** Current app language tag ("am", "en"), or "" when following the system. */
fun currentLanguage(): String = AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore(',').substringBefore('-')

fun setLanguage(tag: String) {
    AppCompatDelegate.setApplicationLocales(
        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag),
    )
}

@Composable
fun calendarName(system: CalendarSystem): String = stringResource(
    when (system) {
        CalendarSystem.SILTE -> R.string.cal_silte
        CalendarSystem.ETHIOPIAN -> R.string.cal_ethiopian
        CalendarSystem.GREGORIAN -> R.string.cal_gregorian
    },
)

@Composable
fun themeName(mode: ThemeMode): String = stringResource(
    when (mode) {
        ThemeMode.SYSTEM -> R.string.theme_system
        ThemeMode.LIGHT -> R.string.theme_light
        ThemeMode.DARK -> R.string.theme_dark
    },
)

@Composable
fun SettingsScreen(
    settings: AppSettings,
    update: ((AppSettings) -> AppSettings) -> Unit,
    navigate: (String) -> Unit,
) {
    val context = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }
    val lang = currentLanguage()

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_settings)) }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 32.dp)) {
            item {
                SectionLabel(stringResource(R.string.section_general))
                SectionCard {
                    SettingRow(
                        stringResource(R.string.language), Icons.Rounded.Language,
                        value = when (lang) { "am" -> "አማርኛ"; "en" -> "English"; else -> stringResource(R.string.theme_system) },
                        onClick = { dialog = "lang" },
                    )
                    RowDivider()
                    SettingRow(stringResource(R.string.theme_mode), Icons.Rounded.DarkMode, value = themeName(settings.themeMode), onClick = { dialog = "theme" })
                    RowDivider()
                    SettingRow(
                        stringResource(R.string.primary_calendar), Icons.Rounded.CalendarMonth,
                        value = calendarName(settings.primaryCalendar), onClick = { dialog = "cal" },
                    )
                }
            }
            item {
                SectionLabel(stringResource(R.string.section_display))
                SectionCard {
                    SwitchRow(
                        stringResource(R.string.display_gregorian), settings.showGregorian, { v -> update { it.copy(showGregorian = v) } },
                        subtitle = stringResource(R.string.display_gregorian_desc),
                    )
                    RowDivider()
                    SwitchRow(
                        stringResource(R.string.use_geez), settings.useGeez, { v -> update { it.copy(useGeez = v) } },
                        subtitle = "፩ ፪ ፫ … ፲፬፻፵፰",
                    )
                }
            }
            item {
                SectionLabel(stringResource(R.string.holidays_to_display))
                SectionCard {
                    SwitchRow(stringResource(R.string.show_public), settings.showPublic, { v -> update { it.copy(showPublic = v) } })
                    RowDivider()
                    SwitchRow(stringResource(R.string.show_orthodox), settings.showOrthodox, { v -> update { it.copy(showOrthodox = v) } })
                    RowDivider()
                    SwitchRow(stringResource(R.string.show_muslim), settings.showMuslim, { v -> update { it.copy(showMuslim = v) } })
                    RowDivider()
                    SwitchRow(stringResource(R.string.show_holiday_notification), settings.dailyDigest, { v -> update { it.copy(dailyDigest = v) } })
                }
            }
            item {
                SectionLabel(stringResource(R.string.section_appearance))
                SectionCard {
                    SettingRow(stringResource(R.string.customize_colors), Icons.Rounded.Palette, onClick = { navigate("settings/colors") })
                    if (Build.VERSION.SDK_INT >= 31) {
                        RowDivider()
                        SwitchRow(
                            stringResource(R.string.dynamic_color), settings.dynamicColor, { v -> update { it.copy(dynamicColor = v) } },
                            icon = Icons.Rounded.AutoAwesome, subtitle = stringResource(R.string.dynamic_color_desc),
                        )
                    }
                    RowDivider()
                    SettingRow(stringResource(R.string.widget_options), Icons.Rounded.Widgets, onClick = { navigate("settings/widgets") })
                    RowDivider()
                    SettingRow(stringResource(R.string.notifications), Icons.Rounded.Notifications, onClick = { navigate("settings/notifications") })
                }
            }
            item {
                SectionLabel(stringResource(R.string.section_data))
                SectionCard {
                    SettingRow(stringResource(R.string.backup_restore), Icons.Rounded.Backup, onClick = { navigate("settings/backup") })
                    RowDivider()
                    SettingRow(stringResource(R.string.export_calendar), Icons.Rounded.FileDownload, onClick = { navigate("settings/export") })
                }
            }
            item {
                SectionLabel(stringResource(R.string.section_about))
                SectionCard {
                    SettingRow(stringResource(R.string.share_app), Icons.Rounded.Share, onClick = { shareApp(context) })
                    RowDivider()
                    SettingRow(stringResource(R.string.rate_app), Icons.Rounded.Star, onClick = { rateApp(context) })
                    RowDivider()
                    SettingRow(stringResource(R.string.contact_us), Icons.Rounded.Email, onClick = { contactUs(context) })
                    RowDivider()
                    SettingRow(stringResource(R.string.about_us), Icons.Rounded.Info, onClick = { navigate("settings/about") })
                    RowDivider()
                    SettingRow(stringResource(R.string.show_onboarding), Icons.Rounded.Replay, onClick = { update { it.copy(onboarded = false) } })
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    when (dialog) {
        "lang" -> ChoiceDialog(
            title = stringResource(R.string.language),
            options = listOf("" to stringResource(R.string.theme_system), "am" to "አማርኛ (Amharic)", "en" to "English"),
            selected = lang, onSelect = ::setLanguage, onDismiss = { dialog = null },
        )
        "theme" -> ChoiceDialog(
            title = stringResource(R.string.theme_mode),
            options = ThemeMode.entries.map { it to themeName(it) },
            selected = settings.themeMode, onSelect = { m -> update { it.copy(themeMode = m) } }, onDismiss = { dialog = null },
        )
        "cal" -> ChoiceDialog(
            title = stringResource(R.string.primary_calendar),
            options = CalendarSystem.entries.map { it to calendarName(it) },
            selected = settings.primaryCalendar, onSelect = { c -> update { it.copy(primaryCalendar = c) } }, onDismiss = { dialog = null },
        )
    }
}

fun shareApp(context: Context) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
        .putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
        .putExtra(Intent.EXTRA_TEXT, context.getString(R.string.share_app_text) + "\n" + PLAY_URL)
    context.startActivity(Intent.createChooser(send, null))
}

fun rateApp(context: Context) {
    val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${context.packageName}"))
    runCatching { context.startActivity(market) }.onFailure {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_URL)))
    }
}

fun contactUs(context: Context) {
    val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
        .putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
    runCatching { context.startActivity(mail) }
}
