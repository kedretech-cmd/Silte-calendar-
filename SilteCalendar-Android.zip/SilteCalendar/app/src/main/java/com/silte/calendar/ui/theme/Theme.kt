package com.silte.calendar.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.ThemeMode

/** Calendar-specific colors that Material's scheme does not cover. */
@Immutable
data class CalendarColors(
    val weekend: Color,
    val holiday: Color,
    val orthodox: Color,
    val muslim: Color,
)

val LocalCalendarColors = staticCompositionLocalOf {
    CalendarColors(Color(0xFFD94040), Color(0xFF10B981), Color(0xFFB45309), Color(0xFF0E7490))
}

object SilteColors {
    val Holiday = Color(0xFF10B981)
    val Orthodox = Color(0xFFD97706)
    val Muslim = Color(0xFF0891B2)
    val EventPalette = listOf(
        0xFF0175C2, 0xFF6366F1, 0xFF10B981, 0xFFF59E0B, 0xFFF43F5E, 0xFF8B5CF6, 0xFF0F766E, 0xFF64748B,
    ).map { it.toInt() }
}

/**
 * Builds a full Material 3 scheme from one seed color, so any user-picked color
 * (including custom ones) yields a harmonious light and dark theme.
 */
object SeedScheme {
    fun create(seed: Int, dark: Boolean): ColorScheme {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val s = hsl[1].coerceIn(0.25f, 0.95f)
        val n = s * 0.10f // neutral chroma: surfaces get a faint tint of the seed
        val h3 = (h + 60f) % 360f
        fun c(hue: Float, sat: Float, light: Float) = Color.hsl(hue, sat.coerceIn(0f, 1f), light.coerceIn(0f, 1f))

        return if (!dark) lightColorScheme(
            primary = c(h, s, 0.40f), onPrimary = Color.White,
            primaryContainer = c(h, s, 0.90f), onPrimaryContainer = c(h, s, 0.14f),
            inversePrimary = c(h, s, 0.80f),
            secondary = c(h, s * 0.30f, 0.40f), onSecondary = Color.White,
            secondaryContainer = c(h, s * 0.45f, 0.90f), onSecondaryContainer = c(h, s * 0.4f, 0.14f),
            tertiary = c(h3, s * 0.5f, 0.38f), onTertiary = Color.White,
            tertiaryContainer = c(h3, s * 0.6f, 0.90f), onTertiaryContainer = c(h3, s * 0.5f, 0.14f),
            background = c(h, n, 0.985f), onBackground = c(h, n, 0.11f),
            surface = c(h, n, 0.985f), onSurface = c(h, n, 0.11f),
            surfaceVariant = c(h, n * 2, 0.90f), onSurfaceVariant = c(h, n * 2, 0.30f),
            surfaceTint = c(h, s, 0.40f),
            inverseSurface = c(h, n, 0.19f), inverseOnSurface = c(h, n, 0.95f),
            outline = c(h, n * 1.5f, 0.50f), outlineVariant = c(h, n * 2, 0.82f),
            surfaceBright = c(h, n, 0.985f), surfaceDim = c(h, n, 0.87f),
            surfaceContainerLowest = Color.White, surfaceContainerLow = c(h, n * 1.5f, 0.965f),
            surfaceContainer = c(h, n * 1.5f, 0.945f), surfaceContainerHigh = c(h, n * 1.5f, 0.925f),
            surfaceContainerHighest = c(h, n * 1.5f, 0.90f),
        ) else darkColorScheme(
            primary = c(h, s, 0.78f), onPrimary = c(h, s, 0.18f),
            primaryContainer = c(h, s * 0.8f, 0.30f), onPrimaryContainer = c(h, s, 0.90f),
            inversePrimary = c(h, s, 0.40f),
            secondary = c(h, s * 0.30f, 0.78f), onSecondary = c(h, s * 0.3f, 0.20f),
            secondaryContainer = c(h, s * 0.30f, 0.28f), onSecondaryContainer = c(h, s * 0.4f, 0.90f),
            tertiary = c(h3, s * 0.5f, 0.78f), onTertiary = c(h3, s * 0.5f, 0.20f),
            tertiaryContainer = c(h3, s * 0.4f, 0.28f), onTertiaryContainer = c(h3, s * 0.5f, 0.90f),
            background = c(h, n, 0.07f), onBackground = c(h, n, 0.90f),
            surface = c(h, n, 0.07f), onSurface = c(h, n, 0.90f),
            surfaceVariant = c(h, n * 2, 0.25f), onSurfaceVariant = c(h, n * 2, 0.80f),
            surfaceTint = c(h, s, 0.78f),
            inverseSurface = c(h, n, 0.90f), inverseOnSurface = c(h, n, 0.20f),
            outline = c(h, n * 1.5f, 0.58f), outlineVariant = c(h, n * 2, 0.30f),
            surfaceBright = c(h, n, 0.24f), surfaceDim = c(h, n, 0.07f),
            surfaceContainerLowest = c(h, n, 0.05f), surfaceContainerLow = c(h, n, 0.10f),
            surfaceContainer = c(h, n, 0.12f), surfaceContainerHigh = c(h, n, 0.16f),
            surfaceContainerHighest = c(h, n, 0.20f),
        )
    }
}

private val AppTypography = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontWeight = FontWeight.SemiBold),
        headlineLarge = t.headlineLarge.copy(fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp, lineHeight = 14.sp),
    )
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun isDark(settings: AppSettings): Boolean = when (settings.themeMode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

@Composable
fun SilteTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = isDark(settings)
    val context = LocalContext.current
    val scheme = remember(dark, settings.primaryColor, settings.dynamicColor) {
        if (settings.dynamicColor && Build.VERSION.SDK_INT >= 31) {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else {
            SeedScheme.create(settings.primaryColor, dark)
        }
    }
    val weekend = Color(settings.weekendColor)
    val calendarColors = remember(dark, weekend) {
        CalendarColors(
            weekend = if (dark) weekend.lighten(0.25f) else weekend,
            holiday = SilteColors.Holiday,
            orthodox = SilteColors.Orthodox,
            muslim = SilteColors.Muslim,
        )
    }
    CompositionLocalProvider(LocalCalendarColors provides calendarColors) {
        MaterialTheme(colorScheme = scheme, typography = AppTypography, shapes = AppShapes, content = content)
    }
}

/** Mixes the color toward white; used to keep custom colors legible in dark mode. */
fun Color.lighten(amount: Float): Color = Color(
    red = red + (1f - red) * amount,
    green = green + (1f - green) * amount,
    blue = blue + (1f - blue) * amount,
    alpha = alpha,
)
