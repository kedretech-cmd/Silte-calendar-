package com.silte.calendar.widget

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.material3.ColorProviders
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.silte.calendar.MainActivity
import com.silte.calendar.R
import com.silte.calendar.container
import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Fmt
import com.silte.calendar.core.Holiday
import com.silte.calendar.core.MonthGrid
import com.silte.calendar.core.Names
import com.silte.calendar.core.todayEpochDay
import com.silte.calendar.core.weekdayOf
import com.silte.calendar.data.AppSettings
import com.silte.calendar.data.EventEntity
import com.silte.calendar.data.EventRepository
import com.silte.calendar.data.Occurrence
import com.silte.calendar.data.ThemeMode
import com.silte.calendar.notify.Notifications
import com.silte.calendar.ui.theme.SeedScheme

object WidgetUpdater {
    suspend fun updateAll(context: Context) {
        runCatching { TodayWidget().updateAll(context) }
        runCatching { MonthWidget().updateAll(context) }
        runCatching { AgendaWidget().updateAll(context) }
    }
}

/** Widget colors follow the app's chosen color and theme mode. */
private fun widgetColors(s: AppSettings): ColorProviders {
    val light = SeedScheme.create(s.primaryColor, dark = false)
    val dark = SeedScheme.create(s.primaryColor, dark = true)
    return when (s.themeMode) {
        ThemeMode.LIGHT -> ColorProviders(light = light, dark = light)
        ThemeMode.DARK -> ColorProviders(light = dark, dark = dark)
        ThemeMode.SYSTEM -> ColorProviders(light = light, dark = dark)
    }
}

private fun openDay(context: Context, epochDay: Long) = actionStartActivity(
    Intent(context, MainActivity::class.java)
        .setData(Uri.parse("silte://day/$epochDay"))
        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        .putExtra(MainActivity.EXTRA_EPOCH_DAY, epochDay),
)

private fun newEvent(context: Context, epochDay: Long) = actionStartActivity(
    Intent(context, MainActivity::class.java)
        .setAction(MainActivity.ACTION_NEW_EVENT)
        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        .putExtra(MainActivity.EXTRA_EPOCH_DAY, epochDay),
)

private fun text(color: ColorProvider, size: Int, bold: Boolean = false, center: Boolean = false) = TextStyle(
    color = color,
    fontSize = size.sp,
    fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    textAlign = if (center) TextAlign.Center else TextAlign.Start,
)

// ───────────────────────────── Today ─────────────────────────────

class TodayWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(setOf(SMALL, WIDE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val c = context.container
        val settings = c.settings.current()
        val today = todayEpochDay()
        val holidays = c.holidays.on(today, settings.holidayFilter)
        val next = EventRepository.agenda(c.events.all(), today, today + 30).firstOrNull()
        val am = Notifications.isAmharic(context)
        provideContent {
            GlanceTheme(colors = widgetColors(settings)) {
                TodayContent(context, settings, today, holidays, next, am)
            }
        }
    }

    companion object {
        val SMALL = DpSize(120.dp, 120.dp)
        val WIDE = DpSize(250.dp, 120.dp)
    }
}

@Composable
private fun TodayContent(context: Context, s: AppSettings, today: Long, holidays: List<Holiday>, next: Occurrence?, am: Boolean) {
    val colors = GlanceTheme.colors
    val silte = CalendarSystem.SILTE.fromEpochDay(today)
    val wide = LocalSize.current.width >= TodayWidget.WIDE.width
    Row(
        GlanceModifier.fillMaxSize().background(colors.primary).cornerRadius(24.dp).padding(14.dp)
            .clickable(openDay(context, today)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = if (wide) GlanceModifier else GlanceModifier.fillMaxWidth()) {
            Text(Names.silteWeekdays[weekdayOf(today)], style = text(colors.onPrimary, 13))
            Text(Fmt.num(silte.day, s.useGeez), style = text(colors.onPrimary, 40, bold = true, center = true))
            Text(Names.silteMonths[silte.month - 1], style = text(colors.onPrimary, 15, bold = true))
            Text(Fmt.num(silte.year, s.useGeez), style = text(colors.onPrimary, 12))
        }
        if (wide) {
            Spacer(GlanceModifier.width(16.dp))
            Column(GlanceModifier.defaultWeight()) {
                Text(Fmt.date(CalendarSystem.ETHIOPIAN, today), style = text(colors.onPrimary, 13), maxLines = 1)
                Text(Fmt.date(CalendarSystem.GREGORIAN, today), style = text(colors.onPrimary, 13), maxLines = 1)
                Spacer(GlanceModifier.height(6.dp))
                val line = holidays.firstOrNull()?.let { "🎉 " + it.name(am) }
                    ?: next?.let { "• " + it.event.title + " · " + Fmt.date(CalendarSystem.SILTE, it.epochDay).substringBefore('፣') }
                if (line != null) Text(line, style = text(colors.onPrimary, 13, bold = true), maxLines = 2)
            }
        }
    }
}

// ───────────────────────────── Month ─────────────────────────────

class MonthWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val c = context.container
        val settings = c.settings.current()
        val today = todayEpochDay()
        val month = CalMonth.containing(settings.primaryCalendar, today)
        val cells = MonthGrid.build(month)
        val from = cells.first().epochDay
        val to = cells.last().epochDay
        val eventDays = EventRepository.occurrences(c.events.all(), from, to).keys
        val holidayDays = c.holidays.inRange(from, to, settings.holidayFilter).filterValues { l -> l.any { it.dayOff } }.keys
        provideContent {
            GlanceTheme(colors = widgetColors(settings)) {
                MonthContent(context, settings, month, today, eventDays, holidayDays)
            }
        }
    }
}

@Composable
private fun MonthContent(context: Context, s: AppSettings, month: CalMonth, today: Long, eventDays: Set<Long>, holidayDays: Set<Long>) {
    val colors = GlanceTheme.colors
    val weekend = ColorProvider(Color(s.weekendColor))
    val cells = MonthGrid.build(month)
    val other = if (month.system == CalendarSystem.GREGORIAN) CalendarSystem.SILTE else CalendarSystem.GREGORIAN
    Column(GlanceModifier.fillMaxSize().background(colors.widgetBackground).cornerRadius(24.dp).padding(10.dp)) {
        Row(GlanceModifier.fillMaxWidth().padding(horizontal = 4.dp).clickable(openDay(context, today)), verticalAlignment = Alignment.CenterVertically) {
            Column(GlanceModifier.defaultWeight()) {
                Text(Fmt.monthTitle(month, s.useGeez), style = text(colors.onSurface, 16, bold = true), maxLines = 1)
                Text(Fmt.span(month, other), style = text(colors.onSurfaceVariant, 11), maxLines = 1)
            }
            Box(
                GlanceModifier.size(32.dp).background(colors.primaryContainer).cornerRadius(16.dp).clickable(newEvent(context, today)),
                contentAlignment = Alignment.Center,
            ) { Text("+", style = text(colors.onPrimaryContainer, 18, bold = true, center = true)) }
        }
        Spacer(GlanceModifier.height(4.dp))
        Row(GlanceModifier.fillMaxWidth()) {
            Names.weekdayHeaders(month.system).forEachIndexed { i, d ->
                Text(
                    d, style = text(if (i == 0 || i == 6) weekend else colors.onSurfaceVariant, 11, bold = true, center = true),
                    modifier = GlanceModifier.defaultWeight(),
                )
            }
        }
        cells.chunked(7).forEach { week ->
            Row(GlanceModifier.fillMaxWidth().defaultWeight(), verticalAlignment = Alignment.CenterVertically) {
                week.forEach { cell ->
                    val isToday = cell.epochDay == today
                    val red = cell.weekday == 0 || cell.weekday == 6 || cell.epochDay in holidayDays
                    val color = when {
                        isToday -> colors.onPrimary
                        !cell.inMonth -> colors.outline
                        red -> weekend
                        else -> colors.onSurface
                    }
                    val label = Fmt.num(cell.primary.day, s.useGeez && month.system != CalendarSystem.GREGORIAN) +
                        if (cell.epochDay in eventDays && cell.inMonth) "•" else ""
                    Box(
                        GlanceModifier.defaultWeight().fillMaxSize().clickable(openDay(context, cell.epochDay)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            (if (isToday) GlanceModifier.background(colors.primary) else GlanceModifier)
                                .size(28.dp).cornerRadius(14.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(label, style = text(color, 12, bold = isToday || cell.epochDay in eventDays, center = true), maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────────── Agenda ─────────────────────────────

private sealed interface AgendaItem {
    val epochDay: Long
    data class Ev(override val epochDay: Long, val event: EventEntity) : AgendaItem
    data class Hol(override val epochDay: Long, val holiday: Holiday) : AgendaItem
}

class AgendaWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val c = context.container
        val settings = c.settings.current()
        val today = todayEpochDay()
        val events = EventRepository.agenda(c.events.all(), today, today + 60).map { AgendaItem.Ev(it.epochDay, it.event) }
        val holidays = c.holidays.inRange(today, today + 60, settings.holidayFilter).values.flatten().map { AgendaItem.Hol(it.epochDay, it) }
        val items = (holidays + events).sortedBy { it.epochDay }.take(20)
        val am = Notifications.isAmharic(context)
        val title = context.getString(R.string.widget_upcoming)
        val empty = context.getString(R.string.widget_nothing_upcoming)
        provideContent {
            GlanceTheme(colors = widgetColors(settings)) {
                AgendaContent(context, settings, today, items, am, title, empty)
            }
        }
    }
}

@Composable
private fun AgendaContent(context: Context, s: AppSettings, today: Long, items: List<AgendaItem>, am: Boolean, title: String, empty: String) {
    val colors = GlanceTheme.colors
    Column(GlanceModifier.fillMaxSize().background(colors.widgetBackground).cornerRadius(24.dp).padding(12.dp)) {
        Row(GlanceModifier.fillMaxWidth().clickable(openDay(context, today)), verticalAlignment = Alignment.CenterVertically) {
            Column(GlanceModifier.defaultWeight()) {
                Text(title, style = text(colors.primary, 12, bold = true))
                Text(Fmt.date(CalendarSystem.SILTE, today, s.useGeez), style = text(colors.onSurface, 15, bold = true), maxLines = 1)
            }
            Box(
                GlanceModifier.size(32.dp).background(colors.primaryContainer).cornerRadius(16.dp).clickable(newEvent(context, today)),
                contentAlignment = Alignment.Center,
            ) { Text("+", style = text(colors.onPrimaryContainer, 18, bold = true, center = true)) }
        }
        Spacer(GlanceModifier.height(8.dp))
        if (items.isEmpty()) {
            Box(GlanceModifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(empty, style = text(colors.onSurfaceVariant, 13, center = true))
            }
        } else {
            LazyColumn(GlanceModifier.fillMaxSize()) {
                items(items) { item ->
                    val (label, accent) = when (item) {
                        is AgendaItem.Ev -> item.event.title to (item.event.color?.let { ColorProvider(Color(it)) } ?: colors.primary)
                        is AgendaItem.Hol -> ("🎉 " + item.holiday.name(am)) to ColorProvider(Color(0xFF10B981))
                    }
                    val ymd = CalendarSystem.SILTE.fromEpochDay(item.epochDay)
                    Row(
                        GlanceModifier.fillMaxWidth().padding(vertical = 4.dp).clickable(openDay(context, item.epochDay)),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(GlanceModifier.width(4.dp).height(32.dp).background(accent).cornerRadius(2.dp)) {}
                        Spacer(GlanceModifier.width(8.dp))
                        Column(GlanceModifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(Fmt.num(ymd.day, s.useGeez), style = text(colors.onSurface, 15, bold = true, center = true))
                            Text(Names.silteMonths[ymd.month - 1], style = text(colors.onSurfaceVariant, 10, center = true), maxLines = 1)
                        }
                        Spacer(GlanceModifier.width(8.dp))
                        Column(GlanceModifier.defaultWeight()) {
                            Text(label, style = text(colors.onSurface, 13, bold = true), maxLines = 1)
                            val sub = if (item is AgendaItem.Ev && !item.event.isAllDay && item.event.reminderHour != null) {
                                Fmt.time(item.event.reminderHour, item.event.reminderMinute ?: 0, true)
                            } else {
                                Fmt.date(CalendarSystem.GREGORIAN, item.epochDay)
                            }
                            Text(sub, style = text(colors.onSurfaceVariant, 11), maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

class TodayWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TodayWidget()
}

class MonthWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MonthWidget()
}

class AgendaWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AgendaWidget()
}
