package com.silte.calendar

import com.silte.calendar.core.CalMonth
import com.silte.calendar.core.CalendarSystem
import com.silte.calendar.core.Geez
import com.silte.calendar.core.HolidayProvider
import com.silte.calendar.core.MonthGrid
import com.silte.calendar.core.Recurrence
import com.silte.calendar.core.Ymd
import com.silte.calendar.core.weekdayOf
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CalendarsTest {
    private fun epoch(y: Int, m: Int, d: Int) = LocalDate.of(y, m, d).toEpochDay()

    @Test fun knownSilteDates() {
        // Values produced by the original React app.
        assertEquals(Ymd(1448, 5, 20), CalendarSystem.SILTE.fromEpochDay(epoch(2026, 11, 14)))
        assertEquals(epoch(2026, 6, 28), CalendarSystem.SILTE.toEpochDay(1448, 1, 1))
        assertEquals(epoch(2025, 6, 27), CalendarSystem.SILTE.toEpochDay(1447, 1, 1))
    }

    @Test fun knownEthiopianDates() {
        assertEquals(Ymd(2019, 3, 5), CalendarSystem.ETHIOPIAN.fromEpochDay(epoch(2026, 11, 14)))
        assertEquals(epoch(2026, 9, 11), CalendarSystem.ETHIOPIAN.toEpochDay(2019, 1, 1))
        assertEquals(epoch(2027, 9, 12), CalendarSystem.ETHIOPIAN.toEpochDay(2020, 1, 1)) // after a leap Pagume
    }

    @Test fun leapYearsMatchOriginalRule() {
        assertTrue(CalendarSystem.SILTE.isLeapYear(1447))
        assertFalse(CalendarSystem.SILTE.isLeapYear(1448))
        assertEquals(6, CalendarSystem.SILTE.daysInMonth(1447, 13))
        assertEquals(5, CalendarSystem.SILTE.daysInMonth(1448, 13))
    }

    @Test fun roundTripEveryDayFor200Years() {
        val start = epoch(1900, 1, 1)
        val end = epoch(2100, 1, 1)
        for (system in CalendarSystem.entries) {
            var e = start
            while (e < end) {
                val ymd = system.fromEpochDay(e)
                assertTrue(system.isValid(ymd.year, ymd.month, ymd.day))
                assertEquals(e, system.toEpochDay(ymd))
                e++
            }
        }
    }

    @Test fun weekdaySundayIsZero() {
        assertEquals(6, weekdayOf(epoch(2026, 11, 14))) // Saturday
        assertEquals(0, weekdayOf(epoch(2026, 11, 15))) // Sunday
    }

    @Test fun gridStartsOnSunday() {
        val cells = MonthGrid.build(CalMonth(CalendarSystem.SILTE, 1448, 5))
        assertEquals(0, cells.first().weekday)
        assertEquals(0, cells.size % 7)
        assertEquals(30, cells.count { it.inMonth })
    }

    @Test fun geezNumerals() {
        assertEquals("፲፬፻፵፰", Geez.format(1448))
        assertEquals("፳፻፲፱", Geez.format(2019))
        assertEquals("፻", Geez.format(100))
        assertEquals("፴", Geez.format(30))
    }

    @Test fun orthodoxEaster() {
        assertEquals(LocalDate.of(2026, 4, 12), HolidayProvider.orthodoxEaster(2026))
        assertEquals(LocalDate.of(2025, 4, 20), HolidayProvider.orthodoxEaster(2025))
    }

    @Test fun yearlyRecurrenceFollowsSilteCalendar() {
        val start = CalendarSystem.SILTE.toEpochDay(1440, 3, 12)
        val next = Recurrence.YEARLY.nextOccurrence(start, CalendarSystem.SILTE.toEpochDay(1448, 1, 1))!!
        assertEquals(Ymd(1448, 3, 12), CalendarSystem.SILTE.fromEpochDay(next))
    }
}
